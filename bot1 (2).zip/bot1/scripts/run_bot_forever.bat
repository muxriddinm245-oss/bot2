@echo off
chcp 65001 >nul
cd /d "%~dp0.."
echo Loyiha: %CD%
echo Ctrl+C yoki yopish oynasi — to'xtatish.
:loop
echo.
echo === %date% %time% — python run_bot.py ===
python run_bot.py
echo.
echo 10 soniya kutib qayta ishga tushirish...
timeout /t 10 /nobreak >nul
goto loop
