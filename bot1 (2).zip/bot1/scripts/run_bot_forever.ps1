# Botni 24/7 ushlab turish: qulay xatolarda yoki to'xtaganda qayta ishga tushadi.
# Ishlatish: PowerShell da:  .\scripts\run_bot_forever.ps1
$ErrorActionPreference = "Continue"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $ProjectRoot

$RestartSec = 10
Write-Host "Loyiha: $ProjectRoot"
Write-Host "Ctrl+C — butunlay to'xtatish."

while ($true) {
    Write-Host "`n=== $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') — python run_bot.py ===`n"
    python run_bot.py
    $code = $LASTEXITCODE
    Write-Host "`nJarayon tugadi (exit=$code). ${RestartSec}s kutib qayta ishga tushamiz...`n"
    Start-Sleep -Seconds $RestartSec
}
