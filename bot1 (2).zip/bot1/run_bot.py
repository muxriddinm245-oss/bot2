"""Ish botini ishga tushirish: python run_bot.py"""

from app.main import main
import asyncio

if __name__ == "__main__":
    asyncio.run(main())
