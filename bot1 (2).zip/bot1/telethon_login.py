
b"""
Bir marta ishga tushiring: Telethon session fayl yaratish (telefon + SMS kodi).
Keyin data/telethon_user.session faylini serverga ko‘chiring (gitga qo‘shmang).

.env: TELEGRAM_API_ID, TELEGRAM_API_HASH, ixtiyoriy TELETHON_SESSION_PATH
"""

import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv
from telethon import TelegramClient


async def main() -> None:
    load_dotenv()
    api_id = int(os.environ["TELEGRAM_API_ID"])
    api_hash = os.environ["TELEGRAM_API_HASH"]
    default = Path(__file__).resolve().parent / "data" / "telethon_user"
    session = os.getenv("TELETHON_SESSION_PATH", str(default)).strip() or str(default)
    Path(session).parent.mkdir(parents=True, exist_ok=True)

    client = TelegramClient(session, api_id, api_hash)
    print("Telefon, SMS kodi va kerak bo‘lsa 2FA so‘raladi...")
    await client.start()
    print("Tayyor. Session:", session + ".session")
    await client.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
