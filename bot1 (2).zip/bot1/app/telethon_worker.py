"""
Oddiy Telegram akkaunt (MTProto) orqali kanal/guruh xabarlarini tinglash.
Bir marta: python telethon_login.py — session fayl yaratiladi, keyin serverda ishlaydi.

Yangi kashfiyot kanallari tasdiqlangach ro‘yxat avtomatik yangilanadi (qayta ishga tushirmasdan).
"""

from __future__ import annotations

import asyncio
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from aiogram import Bot
from telethon import TelegramClient, events, utils
from telethon.errors import RPCError, UserAlreadyParticipantError
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.types import Channel, Chat

from app import db
from app.config import Settings
from app.listings_service import save_listing_and_push

log = logging.getLogger(__name__)


class _TrackedState:
    __slots__ = ("ids", "lock")

    def __init__(self) -> None:
        self.ids: set[int] = set()
        self.lock = asyncio.Lock()


def _message_text(msg) -> str:
    if isinstance(msg, str):
        return msg
    t = getattr(msg, "message", None) or getattr(msg, "raw_text", None) or ""
    return t if isinstance(t, str) else ""


async def _save_telethon_message(bot: Bot, event_or_msg, chat=None, push_enabled: bool = True) -> bool:
    if hasattr(event_or_msg, "id") and hasattr(event_or_msg, "date"):
        msg = event_or_msg
    else:
        candidate = getattr(event_or_msg, "message", None)
        msg = candidate if candidate is not None and not isinstance(candidate, str) else event_or_msg
    text = _message_text(msg)
    if not text.strip():
        return False
    if chat is None and hasattr(event_or_msg, "get_chat"):
        chat = await event_or_msg.get_chat()
    if chat is None:
        return False
    return await save_listing_and_push(
        bot,
        channel_id=int(getattr(chat, "id", 0)),
        message_id=int(getattr(msg, "id", 0)),
        channel_username=getattr(chat, "username", None) or "",
        channel_title=getattr(chat, "title", None) or "",
        body=text,
        posted_at=getattr(msg, "date", None),
        push_enabled=push_enabled,
        check_ingest_filter=False,
        require_city=False,
    )


def _parse_telethon_chat_tokens(raw: tuple[str, ...]) -> list[str]:
    out: list[str] = []
    for token in raw:
        t = token.strip()
        if not t:
            continue
        if re.fullmatch(r"-?\d+", t):
            out.append(t)
            continue
        if "t.me/" in t.lower():
            low = t.lower()
            idx = low.index("t.me/") + len("t.me/")
            slug = t[idx:].lstrip("/").split("/")[0].split("?")[0]
            if slug.startswith("+"):
                log.warning("Telethon: maxfiy t.me/+ havola (%s) — akkaunt bilan avval guruhga kiring.", t)
                continue
            if slug.lower() == "joinchat":
                continue
            out.append(slug.lstrip("@"))
            continue
        out.append(t.lstrip("@"))
    return out


async def _resolve_tracked_peer_ids(
    client: TelegramClient,
    settings: Settings,
) -> tuple[set[int], list]:
    approved_channels = [
        row.get("source_key", "")
        for row in await db.list_approved_sources("channel")
        if row.get("source_key")
    ]
    all_source_tokens = (
        tuple(settings.telethon_channels)
        + tuple(settings.logistics_source_links)
        + tuple(approved_channels)
    )
    tokens = _parse_telethon_chat_tokens(all_source_tokens)

    ids: set[int] = set()
    entities: list = []
    seen: set[int] = set()

    for t in tokens:
        try:
            ent = await client.get_entity(t)
            if isinstance(ent, Channel):
                try:
                    await client(JoinChannelRequest(ent))
                except UserAlreadyParticipantError:
                    pass
            elif isinstance(ent, Chat):
                pass
            else:
                log.warning("Telethon: %s — kanal/guruh emas, o‘tkazildi", t)
                continue
            pid = utils.get_peer_id(ent)
            if pid in seen:
                continue
            seen.add(pid)
            ids.add(pid)
            entities.append(ent)
            log.info("Telethon: tinglanadi — %s (peer_id=%s)", t, pid)
        except RPCError as e:
            log.warning("Telethon: get_entity(%s) — %s", t, e)
        except Exception as e:
            log.warning("Telethon: get_entity(%s) — %s", t, e)

    return ids, entities


async def _refresh_tracked_loop(client: TelegramClient, settings: Settings, tracked: _TrackedState) -> None:
    interval = max(60, int(settings.telethon_tracked_refresh_seconds))
    while True:
        await asyncio.sleep(interval)
        try:
            new_ids, _ = await _resolve_tracked_peer_ids(client, settings)
            async with tracked.lock:
                if new_ids != tracked.ids:
                    log.info(
                        "Telethon: kuzatiladigan chatlar yangilandi (%s → %s ta)",
                        len(tracked.ids),
                        len(new_ids),
                    )
                    tracked.ids = new_ids
        except Exception:
            log.exception("Telethon: tracked ro‘yxatini yangilash")


async def run_until_disconnected(bot: Bot, settings: Settings) -> None:
    if not settings.telethon_enabled:
        return
    if not settings.telethon_api_id or not settings.telethon_api_hash:
        raise RuntimeError("Telethon: TELEGRAM_API_ID va TELEGRAM_API_HASH kerak (my.telegram.org)")

    all_tokens = (
        tuple(settings.telethon_channels)
        + tuple(settings.logistics_source_links)
        + tuple(
            row.get("source_key", "")
            for row in await db.list_approved_sources("channel")
            if row.get("source_key")
        )
    )
    if not _parse_telethon_chat_tokens(all_tokens):
        raise RuntimeError("Telethon: TELETHON_CHANNELS bo‘sh — kamida bitta @kanal yoki chat_id kiriting")

    session_path = Path(settings.telethon_session_path)
    session_path.parent.mkdir(parents=True, exist_ok=True)

    client = TelegramClient(
        str(session_path),
        settings.telethon_api_id,
        settings.telethon_api_hash,
    )

    await client.start()
    if not await client.is_user_authorized():
        await client.disconnect()
        raise RuntimeError(
            "Telethon: akkaunt kirilmagan. Loyiha ildizida: python telethon_login.py"
        )

    tracked = _TrackedState()
    peer_ids, entities = await _resolve_tracked_peer_ids(client, settings)

    if not peer_ids:
        log.warning(
            "Telethon: hech qaysi kanal/guruhga kira olmadi. "
            "Bot davom etadi, TELETHON_CHANNELS ni keyin tekshirib qo‘shasiz."
        )
        await client.disconnect()
        return

    tracked.ids = set(peer_ids)

    if settings.telethon_backfill_limit:
        cutoff = datetime.now(timezone.utc) - timedelta(days=settings.telethon_backfill_days)
        for ent in entities:
            try:
                messages = await client.get_messages(ent, limit=settings.telethon_backfill_limit)
                saved = 0
                text_messages = 0
                for msg in reversed(messages):
                    msg_date = getattr(msg, "date", None)
                    if msg_date and msg_date.astimezone(timezone.utc) < cutoff:
                        continue
                    if _message_text(msg).strip():
                        text_messages += 1
                    if await _save_telethon_message(bot, msg, chat=ent, push_enabled=False):
                        saved += 1
                log.info(
                    "Telethon: backfill %s — olindi=%s matnli=%s yangi=%s",
                    getattr(ent, "username", None) or getattr(ent, "title", "?"),
                    len(messages),
                    text_messages,
                    saved,
                )
            except Exception:
                log.exception("Telethon: oxirgi postlarni olishda xato")

    @client.on(events.NewMessage())
    async def _on_new_message(event: events.NewMessage.Event) -> None:
        try:
            async with tracked.lock:
                ok = event.chat_id in tracked.ids
            if not ok:
                return
            await _save_telethon_message(bot, event)
        except Exception:
            log.exception("Telethon handler xato")

    asyncio.create_task(_refresh_tracked_loop(client, settings, tracked))

    log.info("Telethon: tinglash boshlandi (%s ta manba); avto-yangilanish %s s", len(tracked.ids), settings.telethon_tracked_refresh_seconds)
    await client.run_until_disconnected()
