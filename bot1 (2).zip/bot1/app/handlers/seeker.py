import html
from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app import db
from app.config import get_settings
from app.keyboards import cancel_inline, main_seeker_kb, role_keyboard
from app.matching import (
    body_hints_logistics_cargo,
    direction_match_score,
    matches_seeker_profile,
    text_matches_city,
    wants_any_city,
)
from app.states import SeekerProfile
from app.timefmt import human_age, parse_db_datetime

router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)

CHANNEL_LOOKBACK_DAYS = 5
SETTINGS = get_settings()


def _is_admin(user_id: int) -> bool:
    return user_id in SETTINGS.admin_ids


def _tier_channel_listings(rows: list[dict], city: str, direction: str) -> list[dict]:
    if not rows:
        return []
    t1 = [r for r in rows if matches_seeker_profile(r["body"], city, direction)]
    if t1:
        return t1
    if direction:
        return []
    if wants_any_city(city):
        return rows
    t2 = [r for r in rows if text_matches_city(r["body"], city)]
    if t2:
        return t2
    return []


def _filter_recent_rows(rows: list[dict], days: int = CHANNEL_LOOKBACK_DAYS) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    recent: list[dict] = []
    for row in rows:
        dt = parse_db_datetime(row.get("posted_at") or row.get("created_at"))
        if dt and dt >= cutoff:
            recent.append(row)
    return recent


CHANNEL_CARGO_LOOKBACK_DAYS = 14


async def _cargo_channel_listings(city: str, direction: str, limit: int = 12) -> list[dict]:
    """Kanallardan yuk/logistika iziga ega postlar (baza jadvalidagi yukdan tashqari)."""
    raw = await db.fetch_recent_channel_listings(1500)
    cutoff = datetime.now(timezone.utc) - timedelta(days=CHANNEL_CARGO_LOOKBACK_DAYS)
    recent: list[dict] = []
    for row in raw:
        dt = parse_db_datetime(row.get("posted_at") or row.get("created_at"))
        if dt and dt >= cutoff:
            recent.append(row)
    hints = [r for r in recent if body_hints_logistics_cargo(r.get("body") or "")]
    if not hints:
        return []

    def _score_row(r: dict) -> tuple[int, int]:
        b = r.get("body") or ""
        rid = int(r.get("id") or 0)
        city_boost = 15 if (wants_any_city(city) or text_matches_city(b, city)) else 0
        dir_boost = direction_match_score(b, direction) if (direction or "").strip() else 8
        if direction and dir_boost <= 0 and body_hints_logistics_cargo(b):
            dir_boost = 6
        return (city_boost + dir_boost, rid)

    hints.sort(key=lambda r: _score_row(r), reverse=True)
    matched = [r for r in hints if wants_any_city(city) or text_matches_city((r.get("body") or ""), city)]
    if matched:
        return matched[:limit]
    return hints[:limit]


def _format_cargo_channel_listing(row: dict, snippet_len: int = 420) -> str:
    body = row.get("body") or ""
    snippet = html.escape(body[:snippet_len] + ("…" if len(body) > snippet_len else ""))
    age = human_age(row.get("posted_at") or row.get("created_at"))
    age_line = f"⏱ {html.escape(age)}\n" if age else ""
    ch = (row.get("channel_username") or "").strip()
    title = (row.get("channel_title") or "").strip()
    if ch:
        src = f"@{html.escape(ch.lstrip('@'))}\n"
    elif title:
        src = f"{html.escape(title)}\n"
    else:
        src = ""
    return (
        f"🚛 <b>Kanaldan yuk / logistika</b>\n"
        f"{src}{age_line}{snippet}\n"
        f"—"
    )


async def _matching_channel_listings(city: str, direction: str, limit: int = 8) -> tuple[list[dict], bool]:
    raw_ch = await db.fetch_recent_channel_listings(1000)
    recent = _filter_recent_rows(raw_ch)
    recent_matches = _tier_channel_listings(recent, city, direction)
    if recent_matches:
        return recent_matches[:limit], True
    return _tier_channel_listings(raw_ch, city, direction)[:limit], False


def _format_channel_listing(row: dict, snippet_len: int = 450) -> str:
    body = row.get("body") or ""
    snippet = html.escape(body[:snippet_len] + ("…" if len(body) > snippet_len else ""))
    age = human_age(row.get("posted_at") or row.get("created_at"))
    age_line = f"⏱ {html.escape(age)}\n" if age else ""
    return f"📢 <b>Kanal e’loni</b>\n{age_line}{snippet}\n—"


def _format_cargo_listing(row: dict) -> str:
    route = f"{html.escape(row.get('from_city') or '—')} → {html.escape(row.get('to_city') or '—')}"
    cargo_type = html.escape(row.get("cargo_type") or "Yuk")
    weight = f"\nYuk/og'irlik: {html.escape(row.get('weight') or '—')}" if row.get("weight") else ""
    contact = f"\nAloqa: {html.escape(row.get('contact') or '—')}"
    return (
        f"🚚 <b>Yuk e’loni</b> #{row['id']}\n"
        f"Yo'nalish: {route}\n"
        f"Yuk: {cargo_type}{weight}{contact}\n"
        f"—"
    )


async def _send_recent_channel_matches(message: Message, city: str, direction: str) -> None:
    channels, is_recent = await _matching_channel_listings(city, direction)
    if not channels:
        await message.answer(
            f"Oxirgi {CHANNEL_LOOKBACK_DAYS} kun ichida kanallardan mos e’lon topilmadi. "
            "Yangi e’lon chiqsa avtomatik yuboraman."
        )
        return
    parts = [_format_channel_listing(c) for c in channels]
    title = (
        f"Oxirgi {CHANNEL_LOOKBACK_DAYS} kun ichidan mos kanal e’lonlari:"
        if is_recent
        else "Hozircha oxirgi 5 kunda topilmadi, bazadagi yaqin mos e’lonlar:"
    )
    text = f"{title}\n\n" + "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n…"
    await message.answer(text, parse_mode="HTML", disable_web_page_preview=True)


@router.message(F.text == "Ish qidiruvchi")
async def start_seeker(message: Message, state: FSMContext) -> None:
    await state.set_state(SeekerProfile.city)
    await message.answer(
        "Qayerda ishlashni xohlaysiz? (shahar/viloyat yoki «farqi yo‘q»)\n"
        "Masalan: Toshkent, Samarqand, Andijon, farqi yo‘q",
        reply_markup=cancel_inline(),
    )


@router.message(SeekerProfile.city, F.text)
async def seeker_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgidan oshmasin).")
        return
    await state.update_data(city=message.text)
    await state.set_state(SeekerProfile.direction)
    await message.answer(
        "Qaysi yo‘nalishda ish qidiryapsiz? "
        "(masalan: IT, savdo, haydovchi, logistika, ombor, "
        "<b>onlayn ish</b> / masofaviy, <b>kunlik ish</b> / podrabotka)",
        reply_markup=cancel_inline(),
        parse_mode="HTML",
    )


@router.message(SeekerProfile.direction, F.text)
async def seeker_direction(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing.")
        return
    await state.update_data(direction=message.text)
    await state.set_state(SeekerProfile.contact)
    username = f"@{message.from_user.username}" if message.from_user.username else ""
    example = f"Masalan: {username} yoki +99890..." if username else "Masalan: @username yoki +99890..."
    await message.answer(
        f"Ish beruvchi siz bilan bog‘lanishi uchun telefon yoki Telegram username yozing.\n{example}",
        reply_markup=cancel_inline(),
    )


@router.message(SeekerProfile.contact, F.text)
async def seeker_contact(message: Message, state: FSMContext) -> None:
    contact = message.text.strip()
    if len(contact) < 3 or len(contact) > 200:
        await message.answer("Kontaktni to‘g‘riroq yozing (telefon yoki @username).")
        return
    data = await state.get_data()
    await db.upsert_user_seeker(
        message.from_user.id,
        data.get("city", ""),
        data.get("direction", ""),
        contact,
    )
    await state.clear()
    await message.answer(
        "Profil saqlandi.\n"
        "«Mos ishlar» — sizga aloqador vakansiyalar (masalan, sotuvchi uchun savdo/kassir ham).\n"
        "Ulangan kanallarda yangi post bo‘lsa, shu profil bo‘yicha sizga xabar yuboriladi "
        "(«📣 Avtomatik xabarlar» orqali o‘chirish/yoqish mumkin).\n"
        "Yuk e’lonlari pushini esa «🚚 Yuk alertlar» orqali boshqarasiz.",
        reply_markup=main_seeker_kb(_is_admin(message.from_user.id)),
    )
    await _send_recent_channel_matches(
        message,
        data.get("city", ""),
        data.get("direction", ""),
    )


@router.message(F.text == "Profilimni yangilash")
async def seeker_refresh_profile(message: Message, state: FSMContext) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "seeker":
        await message.answer(
            "Avval «Ish qidiruvchi» rolini tanlang.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    await state.set_state(SeekerProfile.city)
    await message.answer(
        f"Hozirgi profil: {u['city'] or '—'} | {u['direction'] or '—'}\n"
        "Yangi shahar/viloyatni yozing yoki «farqi yo‘q» deb kiriting:",
        reply_markup=cancel_inline(),
    )


@router.message(F.text == "📣 Avtomatik xabarlar")
async def toggle_channel_notify(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "seeker":
        await message.answer(
            "Bu funksiya faqat ish qidiruvchilar uchun.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    cur = int(u.get("notify_channels", 1) or 1)
    new_on = 0 if cur else 1
    await db.set_notify_channels(message.from_user.id, bool(new_on))
    if new_on:
        await message.answer(
            "Kanallardan avtomatik xabarlar: <b>yoqilgan</b>.\n"
            "Profilingizdagi shahar va yo‘nalishga mos postlar chiqqanda yuboraman.",
            parse_mode="HTML",
        )
    else:
        await message.answer(
            "Kanallardan avtomatik xabarlar: <b>o‘chirilgan</b>.\n"
            "«Mos ishlar» bo‘yicha qo‘lda ko‘rishingiz mumkin.",
            parse_mode="HTML",
        )


@router.message(F.text == "🚚 Yuk alertlar")
async def toggle_logistics_notify(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "seeker":
        await message.answer(
            "Bu funksiya faqat ish qidiruvchilar uchun.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    cur = int(u.get("notify_logistics", 1) or 1)
    new_on = 0 if cur else 1
    await db.set_notify_logistics(message.from_user.id, bool(new_on))
    if new_on:
        await message.answer(
            "Yuk alertlar: <b>yoqilgan</b>.\n"
            "Mos yangi yuk e’lonlari chiqqanda avtomatik yuboraman.",
            parse_mode="HTML",
        )
    else:
        await message.answer(
            "Yuk alertlar: <b>o‘chirilgan</b>.\n"
            "Yuklarni qo‘lda «Mos yuklar» bo‘limidan ko‘rishingiz mumkin.",
            parse_mode="HTML",
        )


@router.message(F.text == "Mos ishlar")
async def seeker_jobs(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "seeker":
        await message.answer(
            "Avval ish qidiruvchi sifatida ro‘yxatdan o‘ting.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    city = u.get("city") or ""
    direction = u.get("direction") or ""
    jobs = await db.list_jobs_for_seeker(city, direction)
    channels, _ = await _matching_channel_listings(city, direction)
    cargo_rows = await db.list_logistics_cargo_for_seeker(
        city,
        direction,
        limit=12,
        max_age_hours=SETTINGS.logistics_cargo_ttl_hours,
    )

    if not jobs and not channels and not cargo_rows:
        await message.answer(
            "Hozircha mos e’lon yo‘q. Keyinroq urinib ko‘ring yoki profilingizdagi shaharni kengaytiring."
        )
        return

    parts: list[str] = []
    for j in jobs[:12]:
        sal = f"\nMaosh: {html.escape(j['salary'])}" if j.get("salary") else ""
        contact = f"\nAloqa: {html.escape(j['contact'])}" if j.get("contact") else ""
        dir_line = (
            f"\nYo‘nalish: {html.escape(j['direction'])}" if j.get("direction") else ""
        )
        desc = html.escape(j["description"][:500] + ("…" if len(j["description"]) > 500 else ""))
        parts.append(
            f"#{j['id']} — <b>{html.escape(j['title'])}</b>\n"
            f"📍 {html.escape(j['city'])}{dir_line}{sal}{contact}\n"
            f"{desc}\n"
            f"—"
        )

    for c in channels:
        parts.append(_format_channel_listing(c))

    for row in cargo_rows:
        parts.append(_format_cargo_listing(row))

    text = "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n…"
    await message.answer(text, parse_mode="HTML", disable_web_page_preview=True)


@router.message(F.text == "Mos yuklar")
async def seeker_cargo(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "seeker":
        await message.answer(
            "Avval ish qidiruvchi sifatida ro‘yxatdan o‘ting.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    city = u.get("city") or ""
    direction = u.get("direction") or ""
    cargo_rows = await db.list_logistics_cargo_for_seeker(
        city,
        direction,
        limit=20,
        max_age_hours=SETTINGS.logistics_cargo_ttl_hours,
    )
    ch_cargo = await _cargo_channel_listings(city, direction, limit=12)

    if not cargo_rows and not ch_cargo:
        await message.answer(
            "Hozircha yuk e’lonlari topilmadi — kanallar va bazada yangi post yo‘q yoki "
            f"so‘nggi {CHANNEL_CARGO_LOOKBACK_DAYS} kun ichida mos kelmaydi."
        )
        return

    parts: list[str] = []
    if cargo_rows:
        parts.extend(_format_cargo_listing(row) for row in cargo_rows)
    if ch_cargo:
        if parts:
            parts.append("")
        parts.append(
            f"<i>Quyida kanallardan yuk / logistika postlari (oxirgi ~{CHANNEL_CARGO_LOOKBACK_DAYS} kun):</i>"
        )
        parts.extend(_format_cargo_channel_listing(r) for r in ch_cargo)

    text = "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n…"
    await message.answer(text, parse_mode="HTML", disable_web_page_preview=True)
