"""AI suhbat + bazadan ish/yuk qidirish (Gemini)."""

from __future__ import annotations

import html
import time
from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.enums import ChatAction, ChatType
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app import db
from app.ai_matcher import AiSearchTurn, ai_search_conversation_turn, gemini_chat_reply, heuristic_ai_search_turn
from app.config import get_settings
from app.handlers.seeker import (
    _format_cargo_listing,
    _format_channel_listing,
    _matching_channel_listings,
)
from app.matching import (
    direction_match_score,
    matches_seeker_profile,
    text_matches_city,
    wants_any_city,
)
from app.states import AiChat
from app.timefmt import parse_db_datetime
router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)

_RATE: dict[int, float] = {}
_MIN_INTERVAL_SEC = 10.0


def _rate_allow(user_id: int) -> bool:
    now = time.monotonic()
    last = _RATE.get(user_id, 0.0)
    if now - last < _MIN_INTERVAL_SEC:
        return False
    _RATE[user_id] = now
    return True


def _chat_on(settings) -> bool:
    return settings.ai_chat_enabled and bool(settings.gemini_api_key.strip())


def _format_job_block(j: dict) -> str:
    sal = f"\nMaosh: {html.escape(j['salary'])}" if j.get("salary") else ""
    contact = f"\nAloqa: {html.escape(j['contact'])}" if j.get("contact") else ""
    dir_line = f"\nYo‘nalish: {html.escape(j['direction'])}" if j.get("direction") else ""
    desc_raw = j.get("description") or ""
    desc = html.escape(desc_raw[:500] + ("…" if len(desc_raw) > 500 else ""))
    return (
        f"💼 <b>Botdagi vakansiya</b> #{j['id']}\n"
        f"{html.escape(j.get('title') or '—')}\n"
        f"📍 {html.escape(j.get('city') or '—')}{dir_line}{sal}{contact}\n"
        f"{desc}\n"
        f"—"
    )


_CHANNEL_AI_LOOKBACK_DAYS = 14
_CHANNEL_AI_FETCH = 900


def _filter_channel_rows_by_age(rows: list[dict], days: int) -> list[dict]:
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    out: list[dict] = []
    for row in rows:
        dt = parse_db_datetime(row.get("posted_at") or row.get("created_at"))
        if dt and dt >= cutoff:
            out.append(row)
    return out


def _search_blob(turn: AiSearchTurn, user_question: str) -> str:
    parts = [turn.direction, turn.raw_need, user_question]
    return " ".join(p.strip() for p in parts if p and str(p).strip())[:520]


def _job_direction_for_db(turn: AiSearchTurn, user_question: str) -> str:
    d = f"{turn.direction} {turn.raw_need}".strip()
    if len(d) < 3:
        d = (user_question or "").strip()[:320]
    return d[:320]


def _score_channel_body(body: str, city: str, blob: str) -> int:
    text = body or ""
    if not text.strip():
        return -1
    c = (city or "").strip()
    if c and not wants_any_city(c) and not text_matches_city(text, c):
        return -1
    sc = 0
    if c and not wants_any_city(c) and text_matches_city(text, c):
        sc += 14
    blob = (blob or "").strip()
    short_dir = blob[:260] if blob else ""
    if short_dir and matches_seeker_profile(text, c, short_dir):
        sc = max(sc, 26)
    if blob:
        sc = max(sc, direction_match_score(text, blob))
    if short_dir:
        sc = max(sc, direction_match_score(text, short_dir))
    if c:
        sc = max(sc, direction_match_score(text, c))
    return sc


async def _wide_channel_listings_for_need(
    turn: AiSearchTurn,
    user_question: str,
    limit: int = 14,
) -> list[dict]:
    if turn.intent not in ("job", "both"):
        return []
    blob = _search_blob(turn, user_question)
    city = (turn.city or "").strip()
    if not blob.strip() and not city:
        return []
    raw = await db.fetch_recent_channel_listings(_CHANNEL_AI_FETCH)
    recent = _filter_channel_rows_by_age(raw, _CHANNEL_AI_LOOKBACK_DAYS)
    scored: list[tuple[int, dict]] = []
    for row in recent:
        b = row.get("body") or ""
        s = _score_channel_body(b, city, blob)
        if s < 9:
            continue
        scored.append((s, row))
    scored.sort(key=lambda x: (-x[0], -int(x[1].get("id") or 0)))
    return [r for _, r in scored[:limit]]


async def _execute_ai_search(turn: AiSearchTurn, user_question: str) -> tuple[list[str], bool]:
    settings = get_settings()
    blocks: list[str] = []
    city = (turn.city or "").strip()
    dir_job = _job_direction_for_db(turn, user_question)
    dir_cargo = _search_blob(turn, user_question)[:400]
    found = False

    if turn.intent in ("job", "both"):
        jobs = await db.list_jobs_for_seeker(city, dir_job, limit=12)
        for j in jobs:
            blocks.append(_format_job_block(j))
            found = True
        narrow_ch, _ = await _matching_channel_listings(city, turn.direction, limit=6)
        seen_ids = set()
        for c in narrow_ch:
            cid = int(c.get("id") or 0)
            seen_ids.add(cid)
            blocks.append(_format_channel_listing(c))
            found = True
        wide = await _wide_channel_listings_for_need(turn, user_question, limit=16)
        for c in wide:
            cid = int(c.get("id") or 0)
            if cid in seen_ids:
                continue
            seen_ids.add(cid)
            blocks.append(_format_channel_listing(c))
            found = True

    if turn.intent in ("cargo", "both"):
        cargo_rows = await db.list_logistics_cargo_for_seeker(
            city,
            dir_cargo,
            limit=18,
            max_age_hours=settings.logistics_cargo_ttl_hours,
        )
        for row in cargo_rows:
            blocks.append(_format_cargo_listing(row))
            found = True

    return blocks, found


async def _flush_blocks(message: Message, header: str, blocks: list[str]) -> None:
    buf = header.rstrip()
    max_part = 3800
    for b in blocks:
        chunk = "\n\n" + b if buf else b
        if len(buf) + len(chunk) > max_part:
            if buf:
                await message.answer(buf, parse_mode="HTML", disable_web_page_preview=True)
            buf = b
        else:
            buf = (buf + "\n\n" + b) if buf else b
    if buf:
        await message.answer(buf, parse_mode="HTML", disable_web_page_preview=True)


@router.message(StateFilter("*"), F.text == "🤖 AI yordam")
async def ai_yordam_button(message: Message, state: FSMContext) -> None:
    settings = get_settings()
    if not _chat_on(settings):
        await message.answer(
            "🤖 AI yordam hozir o‘chiq.\n"
            "Admin .env da AI_CHAT_ENABLED=true va GEMINI_API_KEY qo‘yishi kerak."
        )
        return
    await state.set_state(AiChat.question)
    await state.update_data(ai_hist=[])
    await message.answer(
        "Nima kerak — o‘zingizcha yozing, men aniqlashtirib bazadan qidiraman.\n\n"
        "Oddiy gap bilan ham yozishingiz mumkin: «manga supermarketda kassir ish kerak Tashkent».\n\n"
        "Misollar:\n"
        "• «Toshkentda haydovchi ish qidiryapman»\n"
        "• «Buxorodan Toshkentga yuk topishim kerak»\n"
        "• «Savdo sohasida ish, Samarqand»\n\n"
        "Agar narsa no‘aniq bo‘lsa, qisqa savol beraman.\n"
        "Chiqish: /menu"
    )


@router.message(Command("ai"))
async def ai_command(message: Message, state: FSMContext) -> None:
    settings = get_settings()
    if not _chat_on(settings):
        await message.answer("AI yordam hozir mavjud emas.")
        return
    text = (message.text or "").strip()
    parts = text.split(maxsplit=1)
    if len(parts) < 2 or not parts[1].strip():
        await state.set_state(AiChat.question)
        await state.update_data(ai_hist=[])
        await message.answer(
            "Savolingizni yozing yoki: /ai Toshkentda ombor ishchi kerak\n\n"
            "Yoki menyudan 🤖 AI yordam."
        )
        return
    await state.set_state(AiChat.question)
    await state.update_data(ai_hist=[])
    await _process_ai_message(message, state, parts[1].strip())


@router.message(AiChat.question, F.text)
async def ai_question_text(message: Message, state: FSMContext) -> None:
    raw = (message.text or "").strip()
    if raw.startswith("/"):
        await message.answer("Savol matnini oddiy yozing yoki /menu bilan chiqing.")
        return
    settings = get_settings()
    if not _chat_on(settings):
        await state.clear()
        await message.answer("AI yordam vaqtincha o‘chiq.")
        return
    await _process_ai_message(message, state, raw)


async def _process_ai_message(message: Message, state: FSMContext, question: str) -> None:
    settings = get_settings()
    uid = int(message.from_user.id)
    if len(question) > 3500:
        await message.answer("Xabar juda uzun. Qisqaroq yozing.")
        return
    if not _rate_allow(uid):
        await message.answer("Bir oz kutib turing (tez-tez xabar yubormang).")
        return

    data = await state.get_data()
    hist: list[str] = list(data.get("ai_hist") or [])

    await message.bot.send_chat_action(message.chat.id, ChatAction.TYPING)
    turn = await ai_search_conversation_turn(
        api_key=settings.gemini_api_key,
        model=settings.gemini_model,
        history_lines=hist,
        user_message=question,
    )
    if turn is None:
        turn = heuristic_ai_search_turn(question)

    if turn is None:
        fallback = await gemini_chat_reply(
            api_key=settings.gemini_api_key,
            model=settings.gemini_model,
            user_message=question,
        )
        reply = (
            fallback
            or "Hozir javob olinmadi. «Mos ishlar» yoki boshqa shahar/yo‘nalish bilan ham tekshirib ko‘ring.\n"
            "Yoki sal qisqaroq qilib qayta yozing (internet yoki API limiti bo‘lishi mumkin)."
        )
        hist.append(f"User: {question}")
        hist.append(f"Assistant: {reply[:500]}")
        await state.update_data(ai_hist=hist[-20:])
        await message.answer(reply[:4096])
        return

    if not turn.ready:
        follow = turn.follow_up or "Qayerda yoki qaysi ish/yuk yo‘nalishi kerak?"
        hist.append(f"User: {question}")
        hist.append(f"Assistant: {follow}")
        await state.update_data(ai_hist=hist[-20:])
        await message.answer(follow)
        return

    hist.append(f"User: {question}")
    blocks, found = await _execute_ai_search(turn, question)
    hist.append("Assistant: Qidiruv — " + ("topildi" if found else "natija yo'q"))
    await state.update_data(ai_hist=hist[-20:])

    line = (
        f"Shahar/joy: {html.escape(turn.city or '—')} | "
        f"Yo‘nalish: {html.escape(turn.direction or '—')} | "
        f"Ehtiyoj: {html.escape((turn.raw_need or '—')[:180])}"
    )
    header = (
        f"🔎 <b>AI qidiruv natijalari</b>\n"
        f"<i>{line}</i>\n"
        f"({html.escape(turn.intent)})\n"
    )
    if not blocks:
        await message.answer(
            header
            + "\n\nHozir bazada mos e’lon topilmadi. "
            "«Mos ishlar» yoki «Mos yuklar» tugmalarini ham tekshirib ko‘ring, "
            "yoki boshqa shahar / yo‘nalish yozing.",
            parse_mode="HTML",
        )
        return

    await _flush_blocks(message, header, blocks)
    await message.answer(
        "Boshqa joy yoki boshqa ish/yuk uchun shu yerga yozishingiz mumkin. Chiqish: /menu"
    )
