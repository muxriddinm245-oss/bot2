import html
import re

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app import db
from app.config import get_settings
from app.keyboards import cancel_inline
from app.states import AdCreativeSubmission, AdPaymentProof, ServiceRequest

router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)

AD_CHANNEL_COUNT = 50
AD_PRICE_TEXT = "500 000 so'm"

CHANNEL_PACK_SERVICE_TYPE = "Ishchi kanallar topish"
CHANNEL_PACK_PRICE_TEXT = "20 000 000 so'm"


def _is_admin(user_id: int) -> bool:
    return user_id in get_settings().admin_ids


def _service_type_uses_payment_receipt(stype: str) -> bool:
    s = (stype or "").strip().lower()
    return s.startswith("ochiq kanallarga reklama") or s.startswith("ishchi kanallar topish")


def _service_order_kind(service_type: str) -> str:
    s = (service_type or "").strip().lower()
    if s.startswith("ochiq kanallarga reklama"):
        return "ad"
    if s.startswith("ishchi kanallar topish"):
        return "channels"
    return "dev"


async def _ad_payment_text() -> str:
    s = get_settings()
    card = (await db.get_app_config("ad_payment_card", s.ad_payment_card)).strip()
    if not card:
        return "To'lov rekvizitlari admin tomonidan yuboriladi."
    owner = (await db.get_app_config("ad_payment_owner", s.ad_payment_owner)).strip()
    contact = (await db.get_app_config("ad_admin_contact", s.ad_admin_contact)).strip()
    owner_line = f"\nKarta egasi: {owner}" if owner else ""
    contact_line = f"\nAdmin aloqa: {contact}" if contact else ""
    return f"To'lov kartasi: {card}{owner_line}{contact_line}"


async def _dev_order_contact_html() -> str:
    """Sayt/ilova/bot buyurtmasi — mijozga ko‘rinadigan ijrochi aloqasi."""
    s = get_settings()
    raw = (await db.get_app_config("dev_order_contact", s.dev_order_contact)).strip()
    if not raw:
        return ""
    return f"\n\n👤 <b>Buyurtma ijrochisi (aloqa):</b>\n{html.escape(raw[:500])}"


def _service_status_label(status: str) -> str:
    st = (status or "new").strip().lower()
    if st == "payment_pending":
        return "🧾 to'lov kutilmoqda"
    if st == "paid":
        return "💳 to'lov tasdiqlandi"
    if st == "accepted":
        return "✅ qabul qilindi"
    if st == "in_progress":
        return "🛠 jarayonda"
    if st == "done":
        return "🏁 yakunlandi"
    if st == "rejected":
        return "❌ rad etildi"
    return "🆕 yangi"


def _ad_status_kb(request_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="💳 To'lov tasdiq", callback_data=f"adreq:{request_id}:paid"),
                InlineKeyboardButton(text="✅ Qabul", callback_data=f"adreq:{request_id}:accepted"),
                InlineKeyboardButton(text="🛠 Jarayonda", callback_data=f"adreq:{request_id}:in_progress"),
            ],
            [
                InlineKeyboardButton(text="🏁 Yakun", callback_data=f"adreq:{request_id}:done"),
                InlineKeyboardButton(text="❌ Rad", callback_data=f"adreq:{request_id}:rejected"),
            ],
        ]
    )


def _ad_user_submit_kb(request_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📝 Reklama matnini yuborish", callback_data=f"adsend:{request_id}")]
        ]
    )


def _format_service_request_row(row: dict) -> str:
    st = (row.get("service_type") or "").lower()
    if st.startswith("ishchi kanallar topish"):
        head = "📣 Ishchi kanallar buyurtmasi"
    elif st.startswith("ochiq kanallarga reklama"):
        head = "📢 Reklama buyurtma"
    else:
        head = "📋 Xizmat buyurtmasi"
    proof = "ha" if (row.get("payment_proof_file_id") or "").strip() else "yo'q"
    return (
        f"{head} #{row.get('id')}\n"
        f"Status: {_service_status_label(row.get('status') or 'new')}\n"
        f"User: {row.get('user_id')}\n"
        f"Xizmat: {row.get('service_type') or '-'}\n"
        f"Aloqa: {row.get('contact') or '-'}\n"
        f"Chek: {proof}\n"
        f"Matn:\n{(row.get('details') or '-')[:1500]}"
    )


def _extract_request_id(raw: str) -> int:
    text = (raw or "").strip()
    if not text:
        return 0
    m = re.search(r"(?i)(?:/tolov_chek|tolov_chek|chek)\s+(\d+)", text)
    if m:
        return int(m.group(1))
    m2 = re.search(r"#(\d+)", text)
    if m2:
        return int(m2.group(1))
    return 0


async def _save_payment_proof_and_notify(message: Message, request_id: int, file_id: str) -> bool:
    row = await db.get_service_request(request_id)
    if not row:
        await message.answer("Buyurtma topilmadi.")
        return False
    if int(row.get("user_id") or 0) != int(message.from_user.id):
        await message.answer("Bu buyurtma sizga tegishli emas.")
        return False
    if not _service_type_uses_payment_receipt(row.get("service_type") or ""):
        await message.answer("Bu buyurtma turi uchun chek shu komanda orqali qabul qilinmaydi.")
        return False
    ok = await db.set_service_request_payment_proof(request_id, file_id)
    if not ok:
        await message.answer("Chekni saqlab bo'lmadi. Qayta urinib ko'ring.")
        return False
    await message.answer(
        f"✅ Chek qabul qilindi va adminlarga yuborildi.\n"
        f"Buyurtma: #{request_id}\n"
        "Admin chekni ko‘rib, to‘lov to‘g‘ri bo‘lsa «💳 To‘lov tasdiq» beradi — "
        "biroz kuting."
    )
    row = await db.get_service_request(request_id)
    admins = list(get_settings().admin_ids)
    caption = (
        f"🧾 To‘lov cheki keldi\n"
        f"Buyurtma: #{request_id}\n"
        f"User: {message.from_user.id}\n"
        f"Xizmat: {(row or {}).get('service_type') or '-'}\n"
        "Chekni ko‘rib, to‘lov mos bo‘lsa «💳 To‘lov tasdiq» bosing."
    )
    for admin_id in admins[:30]:
        try:
            await message.bot.send_photo(
                admin_id,
                file_id,
                caption=caption,
                reply_markup=_ad_status_kb(request_id),
            )
        except Exception:
            continue
    return True


async def _forward_ad_creative_to_admins(message: Message, request_id: int) -> None:
    admins = list(get_settings().admin_ids)
    if not admins:
        return
    header = (
        f"📣 Reklama materiali keldi\n"
        f"Buyurtma: #{request_id}\n"
        f"User: {message.from_user.id}\n"
        "Quyidagi xabarni ko'rib reklama joylashtiring."
    )
    for admin_id in admins[:30]:
        try:
            await message.bot.send_message(admin_id, header, reply_markup=_ad_status_kb(request_id))
            await message.copy_to(admin_id)
        except Exception:
            continue


@router.message(StateFilter("*"), Command("reklama_rekvizit"))
async def set_ad_payment_requisites(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    raw = (message.text or "").strip()
    payload = raw.partition(" ")[2].strip()
    if not payload:
        current = await _ad_payment_text()
        await message.answer(
            "Format:\n"
            "/reklama_rekvizit &lt;karta&gt; | &lt;karta egasi&gt; | &lt;admin aloqa&gt;\n\n"
            f"Hozirgi:\n{current}"
        )
        return
    parts = [p.strip() for p in payload.split("|")]
    card = parts[0] if len(parts) > 0 else ""
    owner = parts[1] if len(parts) > 1 else ""
    contact = parts[2] if len(parts) > 2 else ""
    if len(card) < 8:
        await message.answer("Karta raqami juda qisqa. Qayta yuboring.")
        return
    await db.set_app_config("ad_payment_card", card[:60])
    await db.set_app_config("ad_payment_owner", owner[:120])
    await db.set_app_config("ad_admin_contact", contact[:120])
    await message.answer(
        "✅ Reklama to'lov rekvizitlari saqlandi.\n"
        f"{await _ad_payment_text()}"
    )


@router.message(StateFilter("*"), Command("dev_buyurtma_aloqa"))
async def set_dev_order_contact(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    raw = (message.text or "").strip()
    payload = raw.partition(" ")[2].strip()
    if not payload:
        s = get_settings()
        cur = (await db.get_app_config("dev_order_contact", s.dev_order_contact)).strip()
        await message.answer(
            "Sayt/ilova/bot buyurtmasida mijozga chiqadigan aloqa.\n\n"
            f"Hozirgi: <code>{html.escape(cur or '—')}</code>\n\n"
            "Yangi qiymat:\n"
            "/dev_buyurtma_aloqa @username yoki +998901112233 yoki ikkalasi",
            parse_mode="HTML",
        )
        return
    await db.set_app_config("dev_order_contact", payload[:500])
    await message.answer(
        "✅ Saqlandi. Endi «Sayt/Ilova/Bot buyurtma» bo‘limida mijozlar buni ko‘radi.",
        parse_mode="HTML",
    )


@router.message(StateFilter("*"), Command("reklama_admin"))
async def ad_admin_panel(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_service_requests("ochiq kanallarga reklama", limit=25)
    if not rows:
        await message.answer("Hozircha reklama buyurtmalari yo'q.")
        return
    for row in rows[:20]:
        await message.answer(_format_service_request_row(row), reply_markup=_ad_status_kb(int(row["id"])))


@router.message(StateFilter("*"), Command("ishchi_kanal_admin"))
async def channel_pack_admin_panel(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_service_requests("ishchi kanallar topish", limit=25)
    if not rows:
        await message.answer("Hozircha ishchi kanallar buyurtmalari yo'q.")
        return
    for row in rows[:20]:
        await message.answer(_format_service_request_row(row), reply_markup=_ad_status_kb(int(row["id"])))


@router.callback_query(F.data.startswith("adreq:"))
async def ad_request_status_cb(cq: CallbackQuery) -> None:
    if not _is_admin(cq.from_user.id):
        await cq.answer("Faqat admin.", show_alert=True)
        return
    parts = (cq.data or "").split(":")
    if len(parts) != 3 or not parts[1].isdigit():
        await cq.answer("Noto'g'ri format.", show_alert=True)
        return
    request_id = int(parts[1])
    status = parts[2].strip().lower()
    if status not in {"paid", "accepted", "in_progress", "done", "rejected"}:
        await cq.answer("Noto'g'ri status.", show_alert=True)
        return
    ok = await db.set_service_request_status(request_id, status)
    if not ok:
        await cq.answer("Buyurtma topilmadi.", show_alert=True)
        return
    row = await db.get_service_request(request_id)
    if row and cq.message:
        await cq.message.edit_text(_format_service_request_row(row), reply_markup=_ad_status_kb(request_id))
        if int(row.get("user_id") or 0) > 0:
            try:
                kind = _service_order_kind(row.get("service_type") or "")
                if kind == "ad":
                    label = "Reklama buyurtmangiz"
                elif kind == "channels":
                    label = "Ishchi kanallar buyurtmangiz"
                else:
                    label = "Buyurtmangiz"
                await cq.bot.send_message(
                    int(row["user_id"]),
                    f"📣 {label} #{request_id} holati: {_service_status_label(status)}",
                )
                if status == "paid":
                    if kind == "ad":
                        await cq.bot.send_message(
                            int(row["user_id"]),
                            "✅ To'lov tasdiqlandi.\n"
                            "Endi reklama matningizni yuboring.",
                            reply_markup=_ad_user_submit_kb(request_id),
                        )
                    elif kind == "channels":
                        await cq.bot.send_message(
                            int(row["user_id"]),
                            "✅ To'lov tasdiqlandi.\n"
                            "So‘ragan yo‘nalishingizga mos holda o‘z bazamizdagi kanallar "
                            "tanlanadi — tez orada havolalarni yuboramiz.",
                        )
            except Exception:
                pass
    await cq.answer("Status yangilandi.")


@router.message(StateFilter("*"), Command("tolov_qildim"))
async def ad_payment_submitted(message: Message) -> None:
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Format: /tolov_qildim &lt;buyurtma_id&gt;")
        return
    request_id = int(parts[1])
    row = await db.get_service_request(request_id)
    if not row:
        await message.answer("Buyurtma topilmadi.")
        return
    if int(row.get("user_id") or 0) != int(message.from_user.id):
        await message.answer("Bu buyurtma sizga tegishli emas.")
        return
    if not _service_type_uses_payment_receipt(row.get("service_type") or ""):
        await message.answer("Bu komanda faqat reklama yoki ishchi kanallar buyurtmalari uchun.")
        return
    await db.set_service_request_status(request_id, "payment_pending")
    await message.answer(
        "✅ Qabul qilindi.\n"
        f"Buyurtma: #{request_id}\n\n"
        "Endi <b>to‘lov chekini</b> albatta yuboring:\n"
        f"1) /tolov_chek {request_id}\n"
        "2) keyin chekni <b>rasm</b> (foto) qilib yuboring — adminlarga tushadi.\n\n"
        "Admin chekni ko‘rib, to‘lov to‘g‘ri bo‘lsa tasdiqlaydi.\n\n"
        f"(ixtiyoriy) /tolov_qildim {request_id} — to‘laganimni bildirish.",
        parse_mode="HTML",
    )
    admins = list(get_settings().admin_ids)
    if not admins:
        return
    admin_text = (
        f"🧾 Foydalanuvchi to‘lov qildi deb yozdi (chek alohida)\n"
        f"Buyurtma: #{request_id}\n"
        f"User: {message.from_user.id}\n"
        f"Xizmat: {row.get('service_type') or '-'}\n"
        f"Aloqa: {row.get('contact') or '-'}\n"
        "Chek kelguncha kuting; chekni ko‘rib «💳 To‘lov tasdiq» bosing."
    )
    for admin_id in admins[:30]:
        try:
            await message.bot.send_message(admin_id, admin_text, reply_markup=_ad_status_kb(request_id))
        except Exception:
            continue


@router.message(StateFilter("*"), Command("tolov_chek"))
async def ad_payment_proof_start(message: Message, state: FSMContext) -> None:
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Format: /tolov_chek &lt;buyurtma_id&gt;\nKeyin chekni foto qilib yuboring.")
        return
    request_id = int(parts[1])
    row = await db.get_service_request(request_id)
    if not row:
        await message.answer("Buyurtma topilmadi.")
        return
    if int(row.get("user_id") or 0) != int(message.from_user.id):
        await message.answer("Bu buyurtma sizga tegishli emas.")
        return
    if not _service_type_uses_payment_receipt(row.get("service_type") or ""):
        await message.answer("Bu komanda faqat reklama yoki ishchi kanallar buyurtmalari uchun.")
        return
    await state.set_state(AdPaymentProof.photo)
    await state.update_data(payment_request_id=request_id)
    await message.answer(
        f"📌 To‘lov <b>chekini</b> yuboring.\n"
        f"Buyurtma: #{request_id}\n\n"
        "Endi chekni <b>rasm (foto)</b> qilib yuboring — adminlarga boradi, "
        "ular ko‘rib to‘lov to‘g‘ri bo‘lsa tasdiqlaydi.",
        parse_mode="HTML",
    )


@router.message(StateFilter("*"), Command("reklama_matn"))
async def ad_creative_start_cmd(message: Message, state: FSMContext) -> None:
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Format: /reklama_matn &lt;buyurtma_id&gt;")
        return
    request_id = int(parts[1])
    row = await db.get_service_request(request_id)
    if not row:
        await message.answer("Buyurtma topilmadi.")
        return
    if int(row.get("user_id") or 0) != int(message.from_user.id):
        await message.answer("Bu buyurtma sizga tegishli emas.")
        return
    await state.set_state(AdCreativeSubmission.text)
    await state.update_data(ad_request_id=request_id)
    await message.answer("Reklama matnini yuboring (post uchun tayyor matn).")


@router.callback_query(F.data.startswith("adsend:"))
async def ad_creative_start_cb(cq: CallbackQuery, state: FSMContext) -> None:
    rid = (cq.data or "").split(":", 1)[1]
    if not rid.isdigit():
        await cq.answer("Noto'g'ri ID.", show_alert=True)
        return
    request_id = int(rid)
    row = await db.get_service_request(request_id)
    if not row:
        await cq.answer("Buyurtma topilmadi.", show_alert=True)
        return
    if int(row.get("user_id") or 0) != int(cq.from_user.id):
        await cq.answer("Bu buyurtma sizga tegishli emas.", show_alert=True)
        return
    await state.set_state(AdCreativeSubmission.text)
    await state.update_data(ad_request_id=request_id)
    await cq.message.answer("Reklama matnini yuboring (post uchun tayyor matn).")
    await cq.answer()


@router.message(AdCreativeSubmission.text, F.text)
async def ad_creative_submit_text(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if len(text) < 10:
        await message.answer("Reklama matnini to'liqroq yozing (kamida 10 belgi).")
        return
    data = await state.get_data()
    request_id = int(data.get("ad_request_id") or 0)
    if request_id <= 0:
        await state.clear()
        await message.answer("Buyurtma topilmadi. /reklama_matn <id> bilan qayta boshlang.")
        return
    block = "[REKLAMA_MATNI]\n" + text
    await db.append_service_request_details(request_id, block)
    await db.set_service_request_status(request_id, "in_progress")
    await state.clear()
    await message.answer("✅ Reklama matningiz qabul qilindi. Admin joylashga oladi.")
    await _forward_ad_creative_to_admins(message, request_id)


@router.message(AdCreativeSubmission.text, F.photo | F.video | F.document | F.animation | F.audio | F.voice)
async def ad_creative_submit_media(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    request_id = int(data.get("ad_request_id") or 0)
    if request_id <= 0:
        await state.clear()
        await message.answer("Buyurtma topilmadi. /reklama_matn <id> bilan qayta boshlang.")
        return
    caption = (message.caption or "").strip()
    if caption:
        block = "[REKLAMA_MATERIAL_CAPTION]\n" + caption
        await db.append_service_request_details(request_id, block)
    await db.set_service_request_status(request_id, "in_progress")
    await state.clear()
    await message.answer("✅ Reklama materiali qabul qilindi. Admin joylashga oladi.")
    await _forward_ad_creative_to_admins(message, request_id)


@router.message(AdCreativeSubmission.text)
async def ad_creative_submit_other(message: Message) -> None:
    await message.answer("Reklama uchun matn, rasm, video yoki fayl yuboring.")


@router.message(AdPaymentProof.photo, F.photo)
async def ad_payment_proof_photo(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    request_id = int(data.get("payment_request_id") or 0)
    if request_id <= 0:
        await state.clear()
        await message.answer("Buyurtma topilmadi. Qayta yuboring: /tolov_chek <id>")
        return
    file_id = message.photo[-1].file_id
    await state.clear()
    await _save_payment_proof_and_notify(message, request_id, file_id)


@router.message(AdPaymentProof.photo)
async def ad_payment_proof_wrong_type(message: Message) -> None:
    await message.answer(
        "Iltimos, to‘lov <b>chekini</b> rasm (photo) qilib yuboring — admin ko‘rib tasdiqlaydi.",
        parse_mode="HTML",
    )


@router.message(StateFilter("*"), F.photo, F.caption)
async def ad_payment_proof_photo_with_caption(message: Message) -> None:
    rid = _extract_request_id(message.caption or "")
    if rid <= 0:
        return
    file_id = message.photo[-1].file_id
    await _save_payment_proof_and_notify(message, rid, file_id)


@router.message(F.text == "💡 Sayt/Ilova/Bot buyurtma")
async def service_order_start(message: Message, state: FSMContext) -> None:
    await state.update_data(is_ad=False, order_mode="dev")
    await state.set_state(ServiceRequest.service_type)
    dev_line = await _dev_order_contact_html()
    await message.answer(
        "Qaysi xizmat kerak?\n"
        "1) Sayt\n"
        "2) Mobil ilova\n"
        "3) Telegram bot\n"
        "Javobni yozing (masalan: Sayt)."
        + dev_line,
        parse_mode="HTML",
        reply_markup=cancel_inline(),
    )


@router.message(F.text == "📢 Reklama berish")
async def ad_order_start(message: Message, state: FSMContext) -> None:
    await state.update_data(is_ad=True, order_mode="ad")
    await state.set_state(ServiceRequest.service_type)
    payment = await _ad_payment_text()
    await message.answer(
        f"📢 Reklama tarifi:\n"
        f"- Joylanish: {AD_CHANNEL_COUNT} ta ochiq kanal\n"
        f"- Narx: {AD_PRICE_TEXT}\n\n"
        f"{payment}\n\n"
        "Reklama paketini tanlang:\n"
        "1) 1 kun\n"
        "2) 3 kun\n"
        "3) 7 kun\n\n"
        "Javobni yozing (masalan: 3 kun).",
        reply_markup=cancel_inline(),
    )


@router.message(F.text == "📣 Ishchi kanallar topish")
async def channel_pack_order_start(message: Message, state: FSMContext) -> None:
    await state.update_data(is_ad=False, order_mode="channels", service_type=CHANNEL_PACK_SERVICE_TYPE)
    await state.set_state(ServiceRequest.details)
    payment = await _ad_payment_text()
    await message.answer(
        "📣 <b>Ishchi kanallar</b> — buyurtmangizda yozgan <b>soha va hududingizga</b> yaqin "
        "bo‘lgan kanallarni <b>o‘z bazamizdan</b> (oldingdan mavjud, tekshirilgan ro‘yxatdan) "
        "tanlab beramiz. Kimga qanday kerak bo‘lsa, shunga mos holda — barcha Telegramni "
        "“qazib” chiqilmaydi.\n\n"
        f"⏱ Odatda javob: 24–72 soat.\n\n"
        f"💰 Narx: <b>{CHANNEL_PACK_PRICE_TEXT}</b>\n\n"
        f"{payment}\n\n"
        "Quyida qisqa yozing: <b>qaysi soha</b> va <b>hudud</b> muhim? "
        "Masalan: «Toshkent, haydovchi va ishchi e’lonlari».",
        parse_mode="HTML",
        reply_markup=cancel_inline(),
    )


def _pick_ad_package(raw: str) -> str:
    t = (raw or "").strip().lower()
    if "7" in t or "hafta" in t:
        return "7 kun"
    if "3" in t:
        return "3 kun"
    return "1 kun"


@router.message(ServiceRequest.service_type, F.text)
async def service_order_type(message: Message, state: FSMContext) -> None:
    raw = message.text.strip()
    normalized = raw.lower()
    data = await state.get_data()
    is_ad = bool(data.get("is_ad"))
    if is_ad:
        package = _pick_ad_package(raw)
        await state.update_data(service_type=f"Ochiq kanallarga reklama ({package})")
        await state.set_state(ServiceRequest.details)
        payment = await _ad_payment_text()
        await message.answer(
            "Reklama ma'lumotlarini yozing:\n"
            f"- Paket: {package}\n"
            f"- Tarqatish: {AD_CHANNEL_COUNT} ta ochiq kanal\n"
            f"- Narx: {AD_PRICE_TEXT}\n"
            f"- {payment}\n"
            "- Qaysi kanal yo'nalishi\n"
            "- Reklama matni yoki taklif\n"
            "- Qaysi hudud/auditoriya",
            reply_markup=cancel_inline(),
        )
        return

    if len(raw) > 60:
        await message.answer("Xizmat nomini qisqaroq yozing.")
        return

    if "sayt" in normalized:
        service_type = "Sayt"
    elif "ilova" in normalized or "app" in normalized:
        service_type = "Mobil ilova"
    elif "bot" in normalized:
        service_type = "Telegram bot"
    else:
        service_type = raw[:60]

    await state.update_data(service_type=service_type)
    await state.set_state(ServiceRequest.details)
    dev_line = await _dev_order_contact_html()
    await message.answer(
        "Qisqacha texnik topshiriq yozing:\n"
        "- Nima qilishi kerak\n"
        "- Kim uchun\n"
        "- Qaysi muddat atrofida"
        + dev_line,
        parse_mode="HTML",
        reply_markup=cancel_inline(),
    )


@router.message(ServiceRequest.details, F.text)
async def service_order_details(message: Message, state: FSMContext) -> None:
    txt = message.text.strip()
    if len(txt) < 12:
        await message.answer("Batafsilroq yozing (kamida 12 belgi).")
        return
    if len(txt) > 4000:
        await message.answer("Matn juda uzun, 4000 belgidan kam yozing.")
        return
    await state.update_data(details=txt)
    await state.set_state(ServiceRequest.contact)
    dev_line = await _dev_order_contact_html()
    await message.answer(
        "Aloqa uchun o‘zingizning username yoki telefoningizni yozing "
        "(buyurtma bo‘yicha siz bilan bog‘lanish uchun)."
        + dev_line,
        parse_mode="HTML",
        reply_markup=cancel_inline(),
    )


@router.message(ServiceRequest.contact, F.text)
async def service_order_contact(message: Message, state: FSMContext) -> None:
    contact = message.text.strip()
    if len(contact) < 3 or len(contact) > 200:
        await message.answer("Aloqa ma'lumotini to'g'riroq kiriting.")
        return
    data = await state.get_data()
    order_mode = (data.get("order_mode") or "").strip()
    if not order_mode:
        order_mode = "ad" if data.get("is_ad") else "dev"
    service_type = (data.get("service_type") or "").strip()
    details = (data.get("details") or "").strip()
    await state.clear()

    rid = await db.insert_service_request(
        user_id=message.from_user.id,
        service_type=service_type,
        details=details,
        contact=contact,
    )
    payment = await _ad_payment_text()
    admins = list(get_settings().admin_ids)

    if order_mode == "ad":
        await message.answer(
            f"Buyurtmangiz qabul qilindi ✅\n"
            f"ID: #{rid}\n"
            f"Xizmat: {service_type or '-'}\n"
            f"Tarif: {AD_CHANNEL_COUNT} ta ochiq kanal | {AD_PRICE_TEXT}\n"
            f"{payment}\n\n"
            "📌 <b>To‘lov cheki</b> shunday yuboriladi:\n"
            f"1) /tolov_chek {rid}\n"
            "2) keyin chekni <b>foto</b> qilib yuboring — adminlarga tushadi.\n"
            "Admin chekni ko‘rib, to‘lov to‘g‘ri bo‘lsa tasdiqlaydi.\n\n"
            f"(ixtiyoriy bildirish) /tolov_qildim {rid}",
            parse_mode="HTML",
        )
        admin_text = (
            f"📢 Yangi reklama buyurtmasi #{rid}\n"
            f"User: {message.from_user.id}\n"
            f"Xizmat: {service_type or '-'}\n"
            f"Tarif: {AD_CHANNEL_COUNT} ta ochiq kanal | {AD_PRICE_TEXT}\n"
            f"Aloqa: {contact}\n"
            f"Matn:\n{details[:1800]}"
        )
    elif order_mode == "channels":
        await message.answer(
            f"Buyurtmangiz qabul qilindi ✅\n"
            f"ID: #{rid}\n"
            f"Xizmat: {service_type or '-'}\n"
            f"Narx: {CHANNEL_PACK_PRICE_TEXT}\n"
            f"{payment}\n\n"
            "📌 <b>To‘lov cheki</b> shunday yuboriladi:\n"
            f"1) /tolov_chek {rid}\n"
            "2) keyin chekni <b>foto</b> qilib yuboring — adminlarga tushadi.\n"
            "Admin chekni ko‘rib, to‘lov to‘g‘ri bo‘lsa tasdiqlaydi; keyin kanal "
            "havolalarini yuboramiz.\n\n"
            f"(ixtiyoriy bildirish) /tolov_qildim {rid}",
            parse_mode="HTML",
        )
        admin_text = (
            f"📣 Yangi ishchi kanallar buyurtmasi #{rid}\n"
            f"User: {message.from_user.id}\n"
            f"Xizmat: {service_type or '-'}\n"
            f"Narx: {CHANNEL_PACK_PRICE_TEXT}\n"
            f"Aloqa: {contact}\n"
            f"Istak:\n{details[:1800]}"
        )
    else:
        dev_line = await _dev_order_contact_html()
        await message.answer(
            f"Buyurtmangiz qabul qilindi ✅\n"
            f"ID: #{rid}\n"
            f"Xizmat: {service_type or '-'}\n"
            "Tez orada siz bilan bog'lanishadi."
            + dev_line,
            parse_mode="HTML",
        )
        admin_text = (
            f"💡 Yangi xizmat buyurtmasi #{rid}\n"
            f"User: {message.from_user.id}\n"
            f"Xizmat: {service_type or '-'}\n"
            f"Aloqa: {contact}\n"
            f"Matn:\n{details[:1800]}"
        )

    if not admins:
        return
    for admin_id in admins[:30]:
        try:
            if order_mode in {"ad", "channels"}:
                await message.bot.send_message(admin_id, admin_text, reply_markup=_ad_status_kb(rid))
            else:
                await message.bot.send_message(admin_id, admin_text)
        except Exception:
            continue

