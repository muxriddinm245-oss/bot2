from aiogram import Bot, F, Router
from aiogram.enums import ChatType
from aiogram.types import Message

from app.listings_service import save_listing_and_push

router = Router()


def _post_text(m: Message) -> str | None:
    if m.text:
        return m.text
    if m.caption:
        return m.caption
    return None


async def _save_listing_and_push(bot: Bot, message: Message) -> None:
    text = _post_text(message)
    if not text or not text.strip():
        return
    chat = message.chat
    await save_listing_and_push(
        bot,
        channel_id=chat.id,
        message_id=message.message_id,
        channel_username=chat.username or "",
        channel_title=chat.title or "",
        body=text,
        posted_at=message.date,
        check_ingest_filter=True,
    )


@router.channel_post()
async def on_channel_post(message: Message, bot: Bot) -> None:
    await _save_listing_and_push(bot, message)


@router.message(
    F.chat.type.in_({ChatType.GROUP, ChatType.SUPERGROUP}),
    F.text | F.caption,
)
async def on_group_or_supergroup_text(message: Message, bot: Bot) -> None:
    """Guruhda admin bo‘lish shart emas; bot oddiy a’zo + BotFather /setprivacy Disable bo‘lishi kerak."""
    if message.text and message.text.startswith("/"):
        return
    await _save_listing_and_push(bot, message)
