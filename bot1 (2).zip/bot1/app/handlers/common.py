from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.filters import Command, CommandStart, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app import db
from app.config import get_settings
from app.keyboards import main_employer_kb, main_seeker_kb, role_keyboard

router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)


def _is_admin(user_id: int) -> bool:
    return user_id in get_settings().admin_ids


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    u = await db.get_user(message.from_user.id)
    if u and u["role"] == "seeker":
        await message.answer(
            "Salom! Siz ish qidiruvchisiz.\n"
            "«Mos ishlar» — bot va ulangan kanallardan mos e’lonlar.\n"
            "Kanal yoki guruhga bot qo‘shilgach yangi postlar profilingizga mos bo‘lsa yuboriladi («📣 Avtomatik xabarlar»).",
            reply_markup=main_seeker_kb(_is_admin(message.from_user.id)),
        )
        return
    if u and u["role"] == "employer":
        await message.answer(
            f"Salom! {u.get('company_name') or 'Kompaniya'}. «Yangi vakansiya» orqali e’lon qo‘ying.",
            reply_markup=main_employer_kb(_is_admin(message.from_user.id)),
        )
        return
    await message.answer(
        "Salom! Men ish topish va ish berishni bog‘layman.\n"
        "Avval ro‘lingizni tanlang yoki pastdagi buyurtma tugmasidan foydalaning:",
        reply_markup=role_keyboard(_is_admin(message.from_user.id)),
    )


@router.message(Command("myid"))
@router.message(Command("id"))
async def show_my_id(message: Message) -> None:
    user_id = int(message.from_user.id)
    is_admin = user_id in get_settings().admin_ids
    await message.answer(
        f"Sizning user ID: <code>{user_id}</code>\n"
        f"Admin holati: <b>{'ha' if is_admin else 'yo‘q'}</b>",
        parse_mode="HTML",
    )


@router.message(Command("menu"))
async def show_menu(message: Message, state: FSMContext) -> None:
    await state.clear()
    u = await db.get_user(message.from_user.id)
    if u and u["role"] == "seeker":
        await message.answer("Menyu yangilandi.", reply_markup=main_seeker_kb(_is_admin(message.from_user.id)))
        return
    if u and u["role"] == "employer":
        await message.answer("Menyu yangilandi.", reply_markup=main_employer_kb(_is_admin(message.from_user.id)))
        return
    await message.answer("Menyu yangilandi.", reply_markup=role_keyboard(_is_admin(message.from_user.id)))


@router.message(F.text == "Rolni o‘zgartirish")
async def change_role(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Yangi rolni tanlang:", reply_markup=role_keyboard(_is_admin(message.from_user.id)))


@router.message(StateFilter("*"), F.text == "🎓 Talabalar uchun")
async def talabalar_uchun_coming_soon(message: Message) -> None:
    await message.answer(
        "🎓 <b>Talabalar uchun</b> bo‘limi hali ishga tushmagan.\n"
        "Tez orada yoqamiz — talabaga mos ish, amaliyot va boshqa imkoniyatlar shu yerda bo‘ladi.",
        parse_mode="HTML",
    )


@router.message(StateFilter("*"), F.text == "💬 Tanishuv")
async def tanishuv_coming_soon(message: Message) -> None:
    await message.answer(
        "💬 <b>Tanishuv</b> bo‘limi hali ishga tushmagan.\n"
        "Tez orada yoqamiz.",
        parse_mode="HTML",
    )


@router.message(StateFilter("*"), F.text == "🌍 Chet eldan ish")
async def chet_el_ish_coming_soon(message: Message) -> None:
    await message.answer(
        "🌍 <b>Chet eldan ish</b> bo‘limi hali ishga tushmagan.\n"
        "Tez orada yoqamiz — chet el vakansiyalari va yo‘l-yo‘riq shu yerda bo‘ladi.",
        parse_mode="HTML",
    )


@router.message(F.text == "🚗 Avto test mini-ilova")
async def auto_test_fallback(message: Message) -> None:
    await message.answer("🚗 Avto test bo‘limi yaqinda ishga tushadi.")


@router.callback_query(F.data == "cancel_fsm")
async def cancel_fsm(cq: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    u = await db.get_user(cq.from_user.id)
    if u and u["role"] == "seeker":
        kb = main_seeker_kb(_is_admin(cq.from_user.id))
    elif u and u["role"] == "employer":
        kb = main_employer_kb(_is_admin(cq.from_user.id))
    else:
        kb = role_keyboard(_is_admin(cq.from_user.id))
    await cq.message.answer("Bekor qilindi.", reply_markup=kb)
    await cq.answer()
