from aiogram import Router

from . import ai_helper, channels, common, employer, logistics, seeker, services


def setup_routers() -> Router:
    root = Router()
    root.include_router(common.router)
    root.include_router(ai_helper.router)
    root.include_router(logistics.router)
    root.include_router(seeker.router)
    root.include_router(employer.router)
    root.include_router(services.router)
    root.include_router(channels.router)
    return root
