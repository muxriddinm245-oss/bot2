import asyncio

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

from app import db
from app.config import get_settings
from app.keyboards import cancel_inline
from app.logistics_push_service import push_cargo_to_seekers
from app.sources import resolve_and_apply
from app.states import LogisticsCargo, LogisticsType, LogisticsVehicle

router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)


def _is_admin(user_id: int) -> bool:
    return user_id in get_settings().admin_ids


def _cargo_status_kb(cargo_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🟢 New", callback_data=f"cargo_st:{cargo_id}:new"),
                InlineKeyboardButton(text="🟡 Band", callback_data=f"cargo_st:{cargo_id}:band"),
                InlineKeyboardButton(text="🔴 Yopildi", callback_data=f"cargo_st:{cargo_id}:yopildi"),
            ]
        ]
    )


def _status_label(status: str) -> str:
    st = (status or "new").strip().lower()
    if st == "band":
        return "🟡 band"
    if st == "yopildi":
        return "🔴 yopildi"
    return "🟢 new"


def _admin_home_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="👥 Users", callback_data="admin_home:users"),
                InlineKeyboardButton(text="📦 Yuk stats", callback_data="admin_home:cargo"),
            ],
            [
                InlineKeyboardButton(text="📢 Reklama", callback_data="admin_home:ads"),
                InlineKeyboardButton(text="🧭 Pending source", callback_data="admin_home:pending"),
            ],
        ]
    )


async def _notify_cargo_owner_status(
    message: Message | None,
    callback: CallbackQuery | None,
    row: dict,
    old_status: str,
    new_status: str,
) -> None:
    owner_id = int(row.get("user_id") or 0)
    if owner_id <= 0:
        return
    actor_id = 0
    bot = None
    if callback:
        actor_id = int(callback.from_user.id)
        bot = callback.bot
    elif message:
        actor_id = int(message.from_user.id)
        bot = message.bot
    if not bot or owner_id == actor_id:
        return
    text = (
        f"ℹ️ CARGO-{row.get('id')} holati yangilandi.\n"
        f"Oldingi: {_status_label(old_status)}\n"
        f"Hozirgi: {_status_label(new_status)}\n"
        f"Yo'nalish: {row.get('from_city') or '-'} → {row.get('to_city') or '-'}"
    )
    try:
        await bot.send_message(owner_id, text)
    except Exception:
        pass


@router.message(F.text == "🚚 Logistika: Yuk bor / Moshina bor")
async def logistics_start(message: Message, state: FSMContext) -> None:
    await state.set_state(LogisticsType.kind)
    await message.answer(
        "Qaysi e'lonni joylamoqchisiz?\n"
        "1) Yuk bor\n"
        "2) Moshina bor\n\n"
        "Javobni yozing (masalan: Yuk bor).",
        reply_markup=cancel_inline(),
    )


@router.message(StateFilter("*"), Command("logistika_admin"))
@router.message(StateFilter("*"), Command("admin"))
@router.message(StateFilter("*"), Command("admin_menu"))
@router.message(StateFilter("*"), Command("admin_home"))
@router.message(StateFilter("*"), F.text == "📊 Logistika admin")
@router.message(StateFilter("*"), F.text == "⚙️ Admin menu")
async def logistics_admin_help(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    await message.answer(
        "Admin buyruqlari:\n"
        "• /users_stats — bot foydalanuvchilari soni\n"
        "• /reklama_admin — reklama buyurtmalar paneli\n"
        "• /ishchi_kanal_admin — ishchi kanallar buyurtmalari (20 mln)\n"
        "• /reklama_rekvizit — reklama karta/kontakt sozlash\n"
        "• /dev_buyurtma_aloqa — sayt/ilova/bot buyurtmasida chiqadigan aloqangiz\n"
        "• /yuklar — oxirgi yuk e'lonlari\n"
        "• /yuk_stats — statuslar bo'yicha statistika\n"
        "• /yuk_tarix — status o'zgarish tarixi\n"
        "• /moshinalar — oxirgi moshina e'lonlari\n"
        "• /sources_pending — yangi topilgan manbalar\n"
        "• /source_approve &lt;id&gt; — manbani tasdiqlash\n"
        "• /source_reject &lt;id&gt; — manbani rad etish\n"
        "• /sources_active — tasdiqlangan manbalar",
        reply_markup=_admin_home_kb(),
    )


@router.callback_query(F.data.startswith("admin_home:"))
async def admin_home_cb(cq: CallbackQuery) -> None:
    if not _is_admin(cq.from_user.id):
        await cq.answer("Faqat admin.", show_alert=True)
        return
    action = (cq.data or "").split(":", 1)[1]
    if action == "users":
        stats = await db.get_user_role_counts()
        await cq.message.answer(
            "👥 Bot foydalanuvchilari statistikasi\n"
            f"Jami: {stats.get('all', 0)}\n"
            f"Ish qidiruvchi: {stats.get('seeker', 0)}\n"
            f"Ish beruvchi: {stats.get('employer', 0)}"
        )
        await cq.answer("Users stat tayyor.")
        return
    if action == "cargo":
        counts = await db.get_logistics_cargo_status_counts()
        total = int(counts.get("new", 0)) + int(counts.get("band", 0)) + int(counts.get("yopildi", 0))
        await cq.message.answer(
            "📦 Yuk status statistikasi\n"
            f"Jami: {total}\n"
            f"🟢 new: {counts.get('new', 0)}\n"
            f"🟡 band: {counts.get('band', 0)}\n"
            f"🔴 yopildi: {counts.get('yopildi', 0)}"
        )
        await cq.answer("Yuk stat tayyor.")
        return
    if action == "ads":
        rows = await db.list_service_requests("ochiq kanallarga reklama", limit=8)
        if not rows:
            await cq.message.answer("Hozircha reklama buyurtmasi yo'q.")
            await cq.answer("Bo'sh.")
            return
        parts = []
        for row in rows:
            parts.append(
                f"#{row['id']} | {row.get('contact') or '-'}\n"
                f"Status: {row.get('status') or 'new'}\n"
                f"{(row.get('service_type') or '-')[:90]}"
            )
        await cq.message.answer("📢 Oxirgi reklama buyurtmalar:\n\n" + "\n—\n".join(parts))
        await cq.message.answer("Batafsil boshqarish: /reklama_admin")
        await cq.answer("Reklama ro'yxati tayyor.")
        return
    if action == "pending":
        rows = await db.list_discovered_sources("pending", 8)
        if not rows:
            await cq.message.answer("Pending manbalar yo'q.")
            await cq.answer("Pending yo'q.")
            return
        parts = [f"#{r['id']} [{r['source_type']}] {r['source_key']}" for r in rows]
        await cq.message.answer("🧭 Pending source:\n" + "\n".join(parts))
        await cq.message.answer("Batafsil boshqarish: /sources_pending")
        await cq.answer("Pending ro'yxat tayyor.")
        return
    await cq.answer("Noma'lum bo'lim.", show_alert=True)


@router.message(StateFilter("*"), Command("users_stats"))
async def users_stats(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    stats = await db.get_user_role_counts()
    await message.answer(
        "👥 Bot foydalanuvchilari statistikasi\n"
        f"Jami: {stats.get('all', 0)}\n"
        f"Ish qidiruvchi: {stats.get('seeker', 0)}\n"
        f"Ish beruvchi: {stats.get('employer', 0)}"
    )


@router.message(StateFilter("*"), Command("yuk_stats"))
async def logistics_cargo_stats(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    counts = await db.get_logistics_cargo_status_counts()
    total = int(counts.get("new", 0)) + int(counts.get("band", 0)) + int(counts.get("yopildi", 0))
    await message.answer(
        "📊 Yuk status statistikasi\n"
        f"Jami: {total}\n"
        f"🟢 new: {counts.get('new', 0)}\n"
        f"🟡 band: {counts.get('band', 0)}\n"
        f"🔴 yopildi: {counts.get('yopildi', 0)}"
    )


@router.message(StateFilter("*"), Command("yuk_tarix"))
async def logistics_cargo_history(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_logistics_status_history(25)
    if not rows:
        await message.answer("Hozircha status o'zgarish tarixi yo'q.")
        return
    for row in rows[:20]:
        txt = (
            f"🕘 #{row['id']} | CARGO-{row['cargo_id']}\n"
            f"{_status_label(row.get('old_status') or 'new')} → {_status_label(row.get('new_status') or 'new')}\n"
            f"Yo'nalish: {row.get('from_city') or '-'} → {row.get('to_city') or '-'}\n"
            f"By: {row.get('changed_by') or '-'}"
        )
        await message.answer(txt)


@router.message(StateFilter("*"), Command("yuklar"))
@router.message(StateFilter("*"), F.text == "📦 Yuklar ro'yxati")
async def logistics_cargo_list(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_logistics_cargo(25)
    if not rows:
        await message.answer("Hozircha yuk e'lonlari yo'q.")
        return
    for row in rows[:20]:
        txt = (
            f"📦 CARGO-{row['id']}\n"
            f"Status: {_status_label(row.get('status') or 'new')}\n"
            f"Yo'nalish: {row.get('from_city') or '-'} → {row.get('to_city') or '-'}\n"
            f"Yuk: {row.get('cargo_type') or '-'} | Og'irlik: {row.get('weight') or '-'}\n"
            f"Aloqa: {row.get('contact') or '-'}"
        )
        await message.answer(txt, reply_markup=_cargo_status_kb(int(row["id"])))


@router.message(StateFilter("*"), Command("moshinalar"))
@router.message(StateFilter("*"), F.text == "🚛 Moshinalar ro'yxati")
async def logistics_vehicle_list(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_logistics_vehicle(25)
    if not rows:
        await message.answer("Hozircha moshina e'lonlari yo'q.")
        return
    parts = []
    for row in rows:
        parts.append(
            f"🚛 VEHICLE-{row['id']}\n"
            f"Yo'nalish: {row.get('from_city') or '-'} → {row.get('to_city') or '-'}\n"
            f"Moshina: {row.get('vehicle_type') or '-'} | Sig'im: {row.get('capacity') or '-'}\n"
            f"Aloqa: {row.get('contact') or '-'}\n"
            f"—"
        )
    text = "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n..."
    await message.answer(text)


@router.message(StateFilter("*"), Command("sources_pending"))
async def sources_pending(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_discovered_sources("pending", 30)
    if not rows:
        await message.answer("Pending manbalar yo'q.")
        return
    await message.answer(f"Topildi: {len(rows)} ta pending manba.")
    for row in rows[:20]:
        txt = (
            f"#{row['id']} [{row['source_type']}]\n"
            f"{row['source_key']}\n"
            f"Ishonch: {row.get('confidence') or 0}\n"
            f"Izoh: {row.get('note') or '-'}"
        )
        kb = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text="✅ Approve", callback_data=f"src_appr:{row['id']}"),
                    InlineKeyboardButton(text="❌ Reject", callback_data=f"src_rej:{row['id']}"),
                ]
            ]
        )
        await message.answer(txt, reply_markup=kb)


@router.message(StateFilter("*"), Command("sources_active"))
async def sources_active(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    rows = await db.list_approved_sources()
    if not rows:
        await message.answer("Tasdiqlangan manbalar yo'q.")
        return
    parts = []
    for row in rows[:50]:
        parts.append(f"[{row['source_type']}] {row['source_key']}")
    text = "Tasdiqlangan manbalar:\n" + "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n..."
    await message.answer(text)


@router.message(StateFilter("*"), Command("source_approve"))
async def source_approve(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Format: /source_approve &lt;id&gt;")
        return
    ok = await db.set_discovered_source_status(int(parts[1]), "approved")
    if not ok:
        await message.answer("ID topilmadi.")
        return
    await resolve_and_apply(message.bot, get_settings())
    await message.answer("Manba tasdiqlandi va ingestga qo'shildi.")


@router.message(StateFilter("*"), Command("source_reject"))
async def source_reject(message: Message) -> None:
    if not _is_admin(message.from_user.id):
        await message.answer("Bu bo'lim faqat admin uchun.")
        return
    parts = (message.text or "").strip().split()
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Format: /source_reject &lt;id&gt;")
        return
    ok = await db.set_discovered_source_status(int(parts[1]), "rejected")
    if not ok:
        await message.answer("ID topilmadi.")
        return
    await message.answer("Manba rad etildi.")


@router.callback_query(F.data.startswith("src_appr:"))
async def source_approve_cb(cq: CallbackQuery) -> None:
    if not _is_admin(cq.from_user.id):
        await cq.answer("Faqat admin.", show_alert=True)
        return
    sid = cq.data.split(":", 1)[1]
    if not sid.isdigit():
        await cq.answer("Noto'g'ri ID.", show_alert=True)
        return
    ok = await db.set_discovered_source_status(int(sid), "approved")
    if not ok:
        await cq.answer("Topilmadi.", show_alert=True)
        return
    await resolve_and_apply(cq.bot, get_settings())
    await cq.message.edit_reply_markup(reply_markup=None)
    await cq.answer("Tasdiqlandi.")


@router.callback_query(F.data.startswith("src_rej:"))
async def source_reject_cb(cq: CallbackQuery) -> None:
    if not _is_admin(cq.from_user.id):
        await cq.answer("Faqat admin.", show_alert=True)
        return
    sid = cq.data.split(":", 1)[1]
    if not sid.isdigit():
        await cq.answer("Noto'g'ri ID.", show_alert=True)
        return
    ok = await db.set_discovered_source_status(int(sid), "rejected")
    if not ok:
        await cq.answer("Topilmadi.", show_alert=True)
        return
    await cq.message.edit_reply_markup(reply_markup=None)
    await cq.answer("Rad etildi.")


@router.callback_query(F.data.startswith("cargo_st:"))
async def cargo_status_cb(cq: CallbackQuery) -> None:
    if not _is_admin(cq.from_user.id):
        await cq.answer("Faqat admin.", show_alert=True)
        return
    parts = (cq.data or "").split(":")
    if len(parts) != 3 or not parts[1].isdigit():
        await cq.answer("Noto'g'ri format.", show_alert=True)
        return
    cargo_id = int(parts[1])
    new_status = parts[2].strip().lower()
    if new_status not in {"new", "band", "yopildi"}:
        await cq.answer("Noto'g'ri status.", show_alert=True)
        return
    before = await db.get_logistics_cargo(cargo_id)
    if not before:
        await cq.answer("Yuk topilmadi.", show_alert=True)
        return
    old_status = (before or {}).get("status") or "new"
    if old_status == new_status:
        await cq.answer("Status o'zgarmadi.")
        return
    ok = await db.set_logistics_cargo_status(cargo_id, new_status)
    if not ok:
        await cq.answer("Yuk topilmadi.", show_alert=True)
        return
    row = await db.get_logistics_cargo(cargo_id)
    await db.add_logistics_status_history(
        cargo_id=cargo_id,
        old_status=old_status,
        new_status=new_status,
        changed_by=int(cq.from_user.id),
    )
    if row:
        await _notify_cargo_owner_status(
            message=None,
            callback=cq,
            row=row,
            old_status=old_status,
            new_status=new_status,
        )
    if row and cq.message:
        txt = (
            f"📦 CARGO-{row['id']}\n"
            f"Status: {_status_label(row.get('status') or 'new')}\n"
            f"Yo'nalish: {row.get('from_city') or '-'} → {row.get('to_city') or '-'}\n"
            f"Yuk: {row.get('cargo_type') or '-'} | Og'irlik: {row.get('weight') or '-'}\n"
            f"Aloqa: {row.get('contact') or '-'}"
        )
        await cq.message.edit_text(txt, reply_markup=_cargo_status_kb(cargo_id))
    await cq.answer(f"Status yangilandi: {new_status}")


@router.message(LogisticsType.kind, F.text)
async def logistics_kind(message: Message, state: FSMContext) -> None:
    text = message.text.strip().lower()
    if "yuk" in text:
        await state.set_state(LogisticsCargo.from_city)
        await message.answer("Yuk qayerdan chiqadi? (shahar/viloyat)")
        return
    if "moshina" in text or "mashina" in text or "transport" in text:
        await state.set_state(LogisticsVehicle.from_city)
        await message.answer("Moshina qayerdan yuradi? (shahar/viloyat)")
        return
    await message.answer("Faqat «Yuk bor» yoki «Moshina bor» deb yozing.")


@router.message(LogisticsCargo.from_city, F.text)
async def cargo_from_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(from_city=message.text.strip())
    await state.set_state(LogisticsCargo.to_city)
    await message.answer("Yuk qayerga boradi?")


@router.message(LogisticsCargo.to_city, F.text)
async def cargo_to_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(to_city=message.text.strip())
    await state.set_state(LogisticsCargo.cargo_type)
    await message.answer("Yuk turi (masalan: mebel, meva-sabzavot, qurilish materiali).")


@router.message(LogisticsCargo.cargo_type, F.text)
async def cargo_type(message: Message, state: FSMContext) -> None:
    if len(message.text) > 200:
        await message.answer("Qisqaroq yozing (200 belgigacha).")
        return
    await state.update_data(cargo_type=message.text.strip())
    await state.set_state(LogisticsCargo.weight)
    await message.answer("Taxminiy og'irlik/hajm (masalan: 5 tonna, 20 m3).")


@router.message(LogisticsCargo.weight, F.text)
async def cargo_weight(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(weight=message.text.strip())
    await state.set_state(LogisticsCargo.contact)
    await message.answer("Aloqa: telefon yoki @username.")


@router.message(LogisticsCargo.contact, F.text)
async def cargo_contact(message: Message, state: FSMContext) -> None:
    contact = message.text.strip()
    if len(contact) < 3 or len(contact) > 200:
        await message.answer("Aloqani to'g'riroq kiriting.")
        return
    data = await state.get_data()
    await state.clear()
    rid = await db.insert_logistics_cargo(
        user_id=message.from_user.id,
        from_city=data.get("from_city", ""),
        to_city=data.get("to_city", ""),
        cargo_type=data.get("cargo_type", ""),
        weight=data.get("weight", ""),
        contact=contact,
    )
    ttl_hours = get_settings().logistics_cargo_ttl_hours
    await message.answer(
        f"✅ Yuk e'loni saqlandi (alohida baza).\n"
        f"ID: CARGO-{rid}\n"
        f"Muddati: {ttl_hours} soat (keyin avtomatik yopiladi)."
    )
    asyncio.create_task(
        push_cargo_to_seekers(
            message.bot,
            rid,
            exclude_user_id=int(message.from_user.id),
        )
    )
    if _is_admin(message.from_user.id):
        return
    admins = list(get_settings().admin_ids)
    if not admins:
        return
    alert = (
        f"🔔 Yangi yuk e'loni: CARGO-{rid}\n"
        f"Yo'nalish: {data.get('from_city', '-') or '-'} → {data.get('to_city', '-') or '-'}\n"
        f"Yuk: {data.get('cargo_type', '-') or '-'}\n"
        f"Aloqa: {contact}"
    )
    for admin_id in admins[:20]:
        try:
            await message.bot.send_message(admin_id, alert, reply_markup=_cargo_status_kb(rid))
        except Exception:
            continue


@router.message(LogisticsVehicle.from_city, F.text)
async def vehicle_from_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(from_city=message.text.strip())
    await state.set_state(LogisticsVehicle.to_city)
    await message.answer("Moshina qayerga boradi?")


@router.message(LogisticsVehicle.to_city, F.text)
async def vehicle_to_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(to_city=message.text.strip())
    await state.set_state(LogisticsVehicle.vehicle_type)
    await message.answer("Moshina turi (masalan: Isuzu, Damas, fura, ref).")


@router.message(LogisticsVehicle.vehicle_type, F.text)
async def vehicle_type(message: Message, state: FSMContext) -> None:
    if len(message.text) > 200:
        await message.answer("Qisqaroq yozing (200 belgigacha).")
        return
    await state.update_data(vehicle_type=message.text.strip())
    await state.set_state(LogisticsVehicle.capacity)
    await message.answer("Sig'imi/tonnaji (masalan: 3 tonna, 20 tonna).")


@router.message(LogisticsVehicle.capacity, F.text)
async def vehicle_capacity(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing (120 belgigacha).")
        return
    await state.update_data(capacity=message.text.strip())
    await state.set_state(LogisticsVehicle.contact)
    await message.answer("Aloqa: telefon yoki @username.")


@router.message(LogisticsVehicle.contact, F.text)
async def vehicle_contact(message: Message, state: FSMContext) -> None:
    contact = message.text.strip()
    if len(contact) < 3 or len(contact) > 200:
        await message.answer("Aloqani to'g'riroq kiriting.")
        return
    data = await state.get_data()
    await state.clear()
    rid = await db.insert_logistics_vehicle(
        user_id=message.from_user.id,
        from_city=data.get("from_city", ""),
        to_city=data.get("to_city", ""),
        vehicle_type=data.get("vehicle_type", ""),
        capacity=data.get("capacity", ""),
        contact=contact,
    )
    await message.answer(
        f"✅ Moshina e'loni saqlandi (alohida baza).\n"
        f"ID: VEHICLE-{rid}"
    )
