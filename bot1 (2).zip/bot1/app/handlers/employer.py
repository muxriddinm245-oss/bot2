import html

from aiogram import F, Router
from aiogram.enums import ChatType
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from app import db
from app.config import get_settings
from app.keyboards import cancel_inline, main_employer_kb, role_keyboard
from app.states import EmployerProfile, NewJob

router = Router()
router.message.filter(F.chat.type == ChatType.PRIVATE)


def _is_admin(user_id: int) -> bool:
    return user_id in get_settings().admin_ids


@router.message(F.text == "Ish beruvchi")
async def start_employer(message: Message, state: FSMContext) -> None:
    await state.set_state(EmployerProfile.company)
    await message.answer(
        "Kompaniya yoki tashkilot nomini yozing (ishchilar sizni shu nom bilan ko‘radi):",
        reply_markup=cancel_inline(),
    )


@router.message(EmployerProfile.company, F.text)
async def employer_company(message: Message, state: FSMContext) -> None:
    if len(message.text) > 200:
        await message.answer("Nom juda uzun. Qisqaroq yozing.")
        return
    await db.upsert_user_employer(message.from_user.id, message.text)
    await state.clear()
    await message.answer(
        "Rahmat! Endi «Yangi vakansiya» orqali e’lon joylashtirishingiz mumkin.",
        reply_markup=main_employer_kb(_is_admin(message.from_user.id)),
    )


@router.message(F.text == "Kompaniyam")
async def employer_show_company(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "employer":
        await message.answer(
            "Siz hali ish beruvchi sifatida ro‘yxatdan o‘tmagansiz.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    await message.answer(f"Kompaniya: {u.get('company_name') or '—'}")


@router.message(F.text == "Mos ishchilar")
async def employer_matching_seekers(message: Message) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "employer":
        await message.answer(
            "Avval «Ish beruvchi» bo‘lib kompaniyani kiriting.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return

    seekers = await db.list_seekers_for_employer(message.from_user.id)
    if not seekers:
        await message.answer(
            "Hozircha sizning vakansiyalaringizga mos ish qidiruvchi topilmadi. "
            "Yangi vakansiya qo‘ying yoki yo‘nalishni kengroq yozing (masalan: savdo/sotuvchi)."
        )
        return

    parts = []
    for s in seekers:
        contact = html.escape(s.get("contact") or "kontakt yo‘q")
        parts.append(
            f"👤 <b>{html.escape(s.get('direction') or 'Ish qidiruvchi')}</b>\n"
            f"📍 {html.escape(s.get('city') or '—')}\n"
            f"Vakansiyangiz: {html.escape(s.get('matched_job_title') or '—')}\n"
            f"Aloqa: {contact}\n"
            f"—"
        )
    text = "\n".join(parts)
    if len(text) > 4000:
        text = text[:3990] + "\n…"
    await message.answer(text, parse_mode="HTML")


@router.message(F.text == "Yangi vakansiya")
async def new_job_start(message: Message, state: FSMContext) -> None:
    u = await db.get_user(message.from_user.id)
    if not u or u["role"] != "employer":
        await message.answer(
            "Avval «Ish beruvchi» bo‘lib kompaniyani kiriting.",
            reply_markup=role_keyboard(_is_admin(message.from_user.id)),
        )
        return
    await state.set_state(NewJob.title)
    await message.answer("Vakansiya sarlavhasi (masalan: Sotuvchi kerak):", reply_markup=cancel_inline())


@router.message(NewJob.title, F.text)
async def new_job_title(message: Message, state: FSMContext) -> None:
    if len(message.text) > 200:
        await message.answer("Sarlavha qisqaroq bo‘lsin.")
        return
    await state.update_data(title=message.text)
    await state.set_state(NewJob.description)
    await message.answer("Ishning vazifalari va talablar (batafsil):", reply_markup=cancel_inline())


@router.message(NewJob.description, F.text)
async def new_job_description(message: Message, state: FSMContext) -> None:
    if len(message.text) > 4000:
        await message.answer("Matn juda uzun. Asosiy qismini 4000 belgidan qisqa qiling.")
        return
    await state.update_data(description=message.text)
    await state.set_state(NewJob.city)
    await message.answer("Ish joyi (shahar yoki viloyat):", reply_markup=cancel_inline())


@router.message(NewJob.city, F.text)
async def new_job_city(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Joy nomi qisqaroq bo‘lsin.")
        return
    await state.update_data(city=message.text)
    await state.set_state(NewJob.direction)
    await message.answer(
        "Yo‘nalish (masalan: savdo, IT, logistika, "
        "onlayn ish, kunlik ish / podrabotka) — "
        "ish qidiruvchilar shu bo‘yicha filtrlashadi:",
        reply_markup=cancel_inline(),
    )


@router.message(NewJob.direction, F.text)
async def new_job_direction(message: Message, state: FSMContext) -> None:
    if len(message.text) > 120:
        await message.answer("Qisqaroq yozing.")
        return
    await state.update_data(direction=message.text)
    await state.set_state(NewJob.salary)
    await message.answer(
        "Maosh yoki shartlar (ixtiyoriy, bo‘lmasa «kelishiladi» deb yozing):",
        reply_markup=cancel_inline(),
    )


@router.message(NewJob.salary, F.text)
async def new_job_salary(message: Message, state: FSMContext) -> None:
    if len(message.text) > 200:
        await message.answer("Maosh/shartlarni qisqaroq yozing.")
        return
    await state.update_data(salary=message.text.strip())
    await state.set_state(NewJob.contact)
    username = f"@{message.from_user.username}" if message.from_user.username else ""
    example = f"Masalan: {username} yoki +99890..." if username else "Masalan: @username yoki +99890..."
    await message.answer(
        f"Aloqa uchun telefon yoki Telegram username yozing.\n{example}",
        reply_markup=cancel_inline(),
    )


@router.message(NewJob.contact, F.text)
async def new_job_contact(message: Message, state: FSMContext) -> None:
    contact = message.text.strip()
    if len(contact) < 3 or len(contact) > 200:
        await message.answer("Kontaktni to‘g‘riroq yozing (telefon yoki @username).")
        return
    data = await state.get_data()
    await state.clear()
    jid = await db.insert_job(
        employer_id=message.from_user.id,
        title=data["title"],
        description=data["description"],
        city=data["city"],
        direction=data.get("direction", ""),
        salary=data.get("salary", ""),
        contact=contact,
    )
    await message.answer(
        f"Vakansiya #{jid} joylandi. Ish qidiruvchilar «Mos ishlar»da kontakt bilan ko‘radi.",
        reply_markup=main_employer_kb(_is_admin(message.from_user.id)),
    )
