"""Bot orqali manba chat_id larini davriy yangilash (yangi tasdiqlangan kanallar)."""

from __future__ import annotations

import asyncio
import logging

from aiogram import Bot

from app.config import get_settings
from app.sources import resolve_and_apply

log = logging.getLogger(__name__)


async def run_sources_resolve_loop(bot: Bot, poll_seconds: int) -> None:
    interval = max(60, int(poll_seconds))
    while True:
        try:
            await resolve_and_apply(bot, get_settings())
        except Exception:
            log.exception("resolve_and_apply")
        await asyncio.sleep(interval)
