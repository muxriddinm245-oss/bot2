from __future__ import annotations

import asyncio
import json
import logging
import re
from dataclasses import dataclass
from typing import Any

import google.generativeai as genai

from app.matching import guess_city_from_user_text, normalize

log = logging.getLogger(__name__)


def _response_text_safe(response: Any) -> str:
    if not response:
        return ""
    try:
        t = getattr(response, "text", None) or ""
        if str(t).strip():
            return str(t).strip()
    except Exception:
        pass
    cand = getattr(response, "candidates", None) or []
    parts_out: list[str] = []
    for c in cand:
        content = getattr(c, "content", None)
        for part in getattr(content, "parts", None) or []:
            txt = getattr(part, "text", None)
            if txt:
                parts_out.append(str(txt))
    return "".join(parts_out).strip()


def _strip_code_fences(raw: str) -> str:
    s = (raw or "").strip()
    if not s.startswith("```"):
        return s
    lines = s.splitlines()
    if lines and lines[0].strip().startswith("```"):
        lines = lines[1:]
    while lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


@dataclass(frozen=True)
class DirectionMatchResult:
    match: bool
    score: int
    reason: str


def _clamp_score(value: Any) -> int:
    try:
        return max(0, min(100, int(value)))
    except (TypeError, ValueError):
        return 0


def _extract_json_object(raw: str) -> dict[str, Any] | None:
    raw = _strip_code_fences((raw or "").strip())
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", raw, flags=re.DOTALL)
    if not match:
        return None
    try:
        parsed = json.loads(match.group(0))
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        return None


def _sync_match_direction(
    *,
    api_key: str,
    model: str,
    listing_text: str,
    seeker_direction: str,
) -> DirectionMatchResult | None:
    genai.configure(api_key=api_key)
    prompt = (
        "You are matching jobs to job seekers. "
        "Given a listing text and seeker direction, decide if they are relevant.\n\n"
        "Return ONLY valid JSON object with keys: "
        '{"match": boolean, "score": number, "reason": string}.\n'
        "score is 0..100 and reflects relevance confidence.\n\n"
        f"seeker_direction: {seeker_direction}\n"
        f"listing_text: {listing_text[:4000]}"
    )
    model_client = genai.GenerativeModel(model_name=model)
    response = model_client.generate_content(prompt)
    data = _extract_json_object(_response_text_safe(response))
    if not data:
        return None
    score = _clamp_score(data.get("score"))
    reason = str(data.get("reason") or "").strip()[:200]
    return DirectionMatchResult(match=bool(data.get("match")), score=score, reason=reason)


async def match_listing_to_direction(
    *,
    api_key: str,
    model: str,
    listing_text: str,
    seeker_direction: str,
) -> DirectionMatchResult | None:
    if not api_key.strip():
        return None
    if not seeker_direction.strip():
        return None
    try:
        return await asyncio.to_thread(
            _sync_match_direction,
            api_key=api_key,
            model=model,
            listing_text=listing_text,
            seeker_direction=seeker_direction,
        )
    except Exception as exc:
        log.debug("Gemini matching failed: %s", exc)
        return None


def _sync_match_cargo(
    *,
    api_key: str,
    model: str,
    cargo_summary: str,
    seeker_city: str,
    seeker_direction: str,
) -> DirectionMatchResult | None:
    genai.configure(api_key=api_key)
    prompt = (
        "You match cargo postings (truck loads, logistics) to seekers who want routes or work. "
        "Given cargo details and seeker preferences, decide if this posting is relevant.\n\n"
        'Return ONLY valid JSON: {"match": boolean, "score": number, "reason": string}.\n'
        "score is 0..100 relevance confidence.\n\n"
        f"seeker_city: {seeker_city}\n"
        f"seeker_direction: {seeker_direction}\n"
        f"cargo_posting: {cargo_summary[:4000]}"
    )
    model_client = genai.GenerativeModel(model_name=model)
    response = model_client.generate_content(prompt)
    data = _extract_json_object(_response_text_safe(response))
    if not data:
        return None
    score = _clamp_score(data.get("score"))
    reason = str(data.get("reason") or "").strip()[:200]
    return DirectionMatchResult(match=bool(data.get("match")), score=score, reason=reason)


async def match_cargo_to_seeker(
    *,
    api_key: str,
    model: str,
    cargo_summary: str,
    seeker_city: str,
    seeker_direction: str,
) -> DirectionMatchResult | None:
    if not api_key.strip():
        return None
    if not seeker_direction.strip():
        return None
    try:
        return await asyncio.to_thread(
            _sync_match_cargo,
            api_key=api_key,
            model=model,
            cargo_summary=cargo_summary,
            seeker_city=seeker_city,
            seeker_direction=seeker_direction,
        )
    except Exception as exc:
        log.debug("Gemini cargo match failed: %s", exc)
        return None


@dataclass(frozen=True)
class AiSearchTurn:
    ready: bool
    follow_up: str
    intent: str  # job | cargo | both
    city: str
    direction: str
    raw_need: str


def _normalize_ai_search(data: dict[str, Any]) -> AiSearchTurn:
    ready = bool(data.get("ready"))
    follow = str(data.get("follow_up") or data.get("followup") or "").strip()[:500]
    intent = (str(data.get("intent") or "both")).strip().lower()
    if intent not in ("job", "cargo", "both"):
        intent = "both"
    city = str(data.get("city") or "").strip()[:120]
    direction = str(data.get("direction") or "").strip()[:250]
    raw_need = str(data.get("raw_need") or data.get("need") or "").strip()[:400]
    return AiSearchTurn(
        ready=ready,
        follow_up=follow,
        intent=intent,
        city=city,
        direction=direction,
        raw_need=raw_need,
    )


def _sync_ai_search_turn(
    *,
    api_key: str,
    model: str,
    history_block: str,
    user_message: str,
) -> AiSearchTurn | None:
    genai.configure(api_key=api_key)
    prompt = (
        "You assist a Telegram bot for Uzbekistan: job vacancies and logistics cargo.\n"
        "The user may write freely e.g. «manga shunaqa ish kerak», salary, skills, city slang.\n"
        "Decide if there is enough to search, or ask ONE short follow-up in Uzbek (Latin).\n\n"
        'Return ONLY valid JSON: {"ready": boolean, "follow_up": string, '
        '"intent": "job"|"cargo"|"both", "city": string, "direction": string, "raw_need": string}\n'
        "Fields:\n"
        '- raw_need: short phrase capturing WHAT they want (job type, route, skills) in Uzbek Latin; '
        "reuse their wording (kassir, haydovchi, yuk Toshkent, etc.).\n"
        '- intent "job" for work/ish/vakansiya, including onlayn/masofaviy/remote and kunlik ish/podrabotka.\n'
        '- intent "cargo" for yuk/logistika/marshrut.\n'
        '- intent "both" if unclear or both.\n'
        '- city: normalized or "farqi yo\'q" if anywhere; "" only if truly unknown.\n'
        "- direction: profession or route line (can overlap raw_need).\n"
        "- ready=true if at least one of: non-empty city, non-empty direction, OR raw_need length >= 12 "
        "(clear request in free text).\n"
        "- If ready=false, follow_up one question; if ready=true, follow_up must be "".\n\n"
        f"Conversation:\n{history_block}\n\nLast user message:\n{user_message[:2000]}"
    )
    model_client = genai.GenerativeModel(model_name=model)
    response = model_client.generate_content(prompt)
    data = _extract_json_object(_response_text_safe(response))
    if not data:
        return None
    turn = _normalize_ai_search(data)
    if turn.ready:
        has_place = bool(turn.city.strip() or turn.direction.strip())
        has_need = len(turn.raw_need.strip()) >= 12
        if not has_place and not has_need:
            return AiSearchTurn(
                ready=False,
                follow_up=turn.follow_up or "Qanday ish yoki qayerda? 1-2 gap bilan yozing.",
                intent=turn.intent,
                city="",
                direction="",
                raw_need="",
            )
    if turn.ready and not (
        turn.city.strip() or turn.direction.strip() or turn.raw_need.strip()
    ):
        return AiSearchTurn(
            ready=False,
            follow_up=turn.follow_up or "Qayerda ishlamoqchi yoki qanday yuk yo‘nalishi kerak?",
            intent=turn.intent,
            city="",
            direction="",
            raw_need="",
        )
    if turn.ready and not turn.raw_need.strip() and len(user_message.strip()) >= 8:
        turn = AiSearchTurn(
            ready=turn.ready,
            follow_up=turn.follow_up,
            intent=turn.intent,
            city=turn.city,
            direction=turn.direction,
            raw_need=user_message.strip()[:400],
        )
    return turn


async def ai_search_conversation_turn(
    *,
    api_key: str,
    model: str,
    history_lines: list[str],
    user_message: str,
) -> AiSearchTurn | None:
    if not api_key.strip():
        return None
    msg = (user_message or "").strip()
    if len(msg) < 1:
        return None
    hist = "\n".join(history_lines[-14:])
    try:
        return await asyncio.to_thread(
            _sync_ai_search_turn,
            api_key=api_key,
            model=model,
            history_block=hist,
            user_message=msg,
        )
    except Exception as exc:
        log.warning("Gemini search turn failed: %s", exc)
        return None


def heuristic_ai_search_turn(user_message: str) -> AiSearchTurn | None:
    """Gemini ishlamasa ham bazadan qidirish uchun sodda taxmin."""
    msg = (user_message or "").strip()
    if len(msg) < 4:
        return None
    low = normalize(msg)
    cargo_hit = any(
        k in low
        for k in (
            "yuk",
            "fura",
            "logistika",
            "tirkama",
            "marshrut",
            "tashish",
            "tirkaman",
        )
    )
    job_hit = any(
        k in low
        for k in (
            " ish",
            "ish ",
            "ish,",
            "ish.",
            "ishga",
            "ishchi",
            "ishlash",
            "ishlamoqchi",
            "vakansiya",
            "rabota",
            "kerak",
            "qidir",
            "qilmoqchi",
            "moqchiman",
            "haydovchi",
            "haydovchilik",
            "xaydovchi",
            "shofyor",
            "voditel",
            "operator",
            "qabul",
            "band",
        )
    )
    if cargo_hit and job_hit:
        intent = "both"
    elif cargo_hit:
        intent = "cargo"
    else:
        intent = "job"
    city = guess_city_from_user_text(msg)
    remote_hit = any(
        k in low
        for k in (
            "onlayn",
            "online",
            "masofaviy",
            "remote",
            "uyda",
            "uydan",
            "internet orqali",
            "masofadan",
        )
    )
    if not city and remote_hit:
        city = "farqi yo'q"
    raw_need = msg[:400]
    direction = msg[:250]
    if len(msg) < 8 and not city.strip():
        return AiSearchTurn(
            ready=False,
            follow_up="Qayerda ishlamoqchisiz yoki qanday ish turi kerak? Qisqa yozing.",
            intent=intent,
            city="",
            direction="",
            raw_need="",
        )
    return AiSearchTurn(
        ready=True,
        follow_up="",
        intent=intent,
        city=city[:120],
        direction=direction,
        raw_need=raw_need,
    )


def _sync_discover_channel_score(
    *,
    api_key: str,
    model: str,
    channel_key: str,
    page_excerpt: str,
) -> int | None:
    genai.configure(api_key=api_key)
    prompt = (
        "You score whether a Telegram channel is mainly about job postings (vakansiya, ish, rabota) "
        "OR trucking / cargo / logistics (yuk, fura, transport) in Uzbekistan / Central Asia.\n"
        'Return ONLY JSON: {"score": number, "relevant": boolean}\n'
        "score 0-100; 85+ strong match, 0-15 off-topic (memes, crypto, entertainment).\n\n"
        f"channel_or_link: {channel_key[:160]}\n"
        f"text_seen_on_discovery_page: {page_excerpt[:1400]}"
    )
    model_client = genai.GenerativeModel(model_name=model)
    response = model_client.generate_content(prompt)
    data = _extract_json_object(_response_text_safe(response))
    if not data:
        return None
    return _clamp_score(data.get("score"))


async def gemini_channel_discovery_score(
    *,
    api_key: str,
    model: str,
    channel_key: str,
    page_excerpt: str,
) -> int | None:
    if not api_key.strip():
        return None
    key = (channel_key or "").strip()
    if not key:
        return None
    excerpt = (page_excerpt or "").strip()[:2000]
    try:
        return await asyncio.to_thread(
            _sync_discover_channel_score,
            api_key=api_key,
            model=model,
            channel_key=key,
            page_excerpt=excerpt,
        )
    except Exception as exc:
        log.debug("Gemini channel discovery failed: %s", exc)
        return None


def _sync_chat_reply(*, api_key: str, model: str, user_message: str) -> str | None:
    genai.configure(api_key=api_key)
    prompt = (
        "Sen O‘zbekiston bo‘yicha ish qidirish va yuk tashish (logistika) bo‘yicha yordamchisan.\n"
        "Javobni qisqa va aniq ber. O‘zbek lotin alifbosida yoz.\n"
        "Bu yerda Telegram bot bor: vakansiya, logistika e’lonlari, profil, avtomatik bildirishnomalar.\n"
        "Savol bot buyrug‘lari haqida bo‘lsa, /start va /menu ishlatishni aytding.\n"
        "Sen rasmiy yurist yoki buxgalter emassan — murakkab huquqiy/moliya masalalarida mutaxassisga "
        "murojaat qilishni maslahat ber.\n\n"
        f"Foydalanuvchi savoli:\n{user_message[:3500]}"
    )
    model_client = genai.GenerativeModel(model_name=model)
    response = model_client.generate_content(prompt)
    text = _response_text_safe(response)
    return text[:4096] if text else None


async def gemini_chat_reply(*, api_key: str, model: str, user_message: str) -> str | None:
    if not api_key.strip():
        return None
    msg = (user_message or "").strip()
    if len(msg) < 2:
        return None
    try:
        return await asyncio.to_thread(
            _sync_chat_reply,
            api_key=api_key,
            model=model,
            user_message=msg,
        )
    except Exception as exc:
        log.warning("Gemini chat failed: %s", exc)
        return None
