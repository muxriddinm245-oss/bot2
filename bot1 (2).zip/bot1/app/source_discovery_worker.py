from __future__ import annotations

import asyncio
import html
import logging
import re
from urllib.request import Request, urlopen

from app import db
from app.ai_matcher import gemini_channel_discovery_score
from app.config import get_settings

log = logging.getLogger(__name__)

_USERNAME_RE = re.compile(r"@([A-Za-z0-9_]{4,64})")
_URL_RE = re.compile(r"https?://[^\s\"'<>]+", re.IGNORECASE)
_LOG_KEYWORD_RE = re.compile(
    r"(yuk|gruz|cargo|fura|isuzu|damas|transport|logistika|dispatcher|dispecher|ish|vakansiya|vakan|rabota|job|work|onlayn|online|masofaviy|remote|podrabotka|kunlik)",
    re.IGNORECASE,
)


def _download(url: str, timeout: int = 20) -> str:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; Bot1Discovery/1.1)"})
    with urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    return raw.decode("utf-8", errors="ignore")


def _extract_text(page_html: str) -> str:
    text = re.sub(r"(?is)<script.*?>.*?</script>|<style.*?>.*?</style>", " ", page_html)
    text = re.sub(r"(?is)<[^>]+>", " ", text)
    text = html.unescape(text)
    text = re.sub(r"\s+", " ", text)
    return text


def _normalize_channel(username: str) -> str:
    return f"@{username.lstrip('@').strip()}"


def _channel_confidence(username: str, note_text: str) -> int:
    txt = f"{username} {note_text}".lower()
    score = 40
    if any(k in txt for k in ("ish", "vakans", "rabota", "job", "work")):
        score += 35
    if any(k in txt for k in ("onlayn", "online", "masofaviy", "remote", "freelance", "podrabotka", "kunlik")):
        score += 15
    if any(k in txt for k in ("yuk", "cargo", "gruz", "logist", "transport", "fura", "moshina")):
        score += 25
    return min(100, score)


async def _boost_with_ai(
    channel_key: str,
    excerpt: str,
    base_conf: int,
    settings,
    ai_remaining: list[int],
) -> int:
    if ai_remaining[0] <= 0:
        return base_conf
    if not settings.ai_discovery_enabled or not settings.gemini_api_key.strip():
        return base_conf
    if base_conf < 42:
        return base_conf
    ai_remaining[0] -= 1
    ai_s = await gemini_channel_discovery_score(
        api_key=settings.gemini_api_key,
        model=settings.gemini_model,
        channel_key=channel_key,
        page_excerpt=excerpt,
    )
    if ai_s is None:
        return base_conf
    return max(base_conf, int(ai_s))


async def _discover_from_page(url: str, auto_approve: bool = True) -> None:
    settings = get_settings()
    threshold = int(settings.source_discovery_approve_min_score)
    ai_remaining = [18]

    try:
        raw = await asyncio.to_thread(_download, url)
    except Exception as e:
        log.debug("Discovery page fetch fail: %s (%s)", url, e)
        return
    text = _extract_text(raw)
    if not _LOG_KEYWORD_RE.search(text):
        return

    excerpt = text[:2200]
    usernames = {_normalize_channel(m.group(1)) for m in _USERNAME_RE.finditer(text)}
    for uname in sorted(usernames):
        conf = _channel_confidence(uname, text[:900])
        conf = await _boost_with_ai(uname, excerpt, conf, settings, ai_remaining)
        await db.upsert_discovered_source(
            "channel",
            uname,
            confidence=conf,
            note=f"auto-discovered from {url}" + (" +ai" if settings.ai_discovery_enabled else ""),
            status="approved" if auto_approve and conf >= threshold else "pending",
        )

    for m in _URL_RE.finditer(raw):
        link = m.group(0).strip().rstrip(").,")
        if "t.me/" in link.lower() or "telegram.me/" in link.lower():
            conf = _channel_confidence(link, text[:900])
            conf = await _boost_with_ai(link, excerpt, conf, settings, ai_remaining)
            await db.upsert_discovered_source(
                "channel",
                link,
                confidence=conf,
                note=f"auto-discovered t.me link from {url}",
                status="approved" if auto_approve and conf >= threshold else "pending",
            )
        elif _LOG_KEYWORD_RE.search(link):
            await db.upsert_discovered_source(
                "site",
                link,
                confidence=40,
                note=f"auto-discovered url from {url}",
                status="pending",
            )


async def run_source_discovery_loop(
    seed_urls: tuple[str, ...],
    poll_seconds: int = 3600,
    auto_approve: bool = True,
) -> None:
    urls = tuple(u.strip() for u in seed_urls if u.strip())
    if not urls:
        return
    log.info("Source discovery yoqildi: %s ta seed URL", len(urls))
    while True:
        for url in urls:
            await _discover_from_page(url, auto_approve=auto_approve)
            await asyncio.sleep(0.35)
        await asyncio.sleep(max(300, int(poll_seconds or 3600)))
