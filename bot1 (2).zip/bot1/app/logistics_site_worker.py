from __future__ import annotations

import asyncio
import hashlib
import html
import logging
import re
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from aiogram import Bot

from app import db
from app.logistics_ingest_service import save_logistics_from_text
from app.logistics_push_service import push_cargo_to_seekers

log = logging.getLogger(__name__)

_KEYWORD_RE = re.compile(
    r"(yuk|gruz|cargo|fura|isuzu|damas|moshina|mashina|transport|dispecher|logistika)",
    re.IGNORECASE,
)


def _download_html(url: str, timeout: int = 20) -> str:
    req = Request(url, headers={"User-Agent": "Mozilla/5.0 (compatible; Bot1Logistics/1.0)"})
    with urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    return raw.decode("utf-8", errors="ignore")


def _extract_candidates(page_html: str, limit: int = 20) -> list[str]:
    cleaned = re.sub(r"(?is)<script.*?>.*?</script>|<style.*?>.*?</style>", " ", page_html)
    cleaned = re.sub(r"(?is)<[^>]+>", " ", cleaned)
    cleaned = html.unescape(cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned)
    # Nuqtalar bo'yicha bo'lib chiqamiz, keyin logistika keyword borlarini olamiz.
    chunks = re.split(r"[.!?•\n\r]+", cleaned)
    out: list[str] = []
    seen: set[str] = set()
    for c in chunks:
        t = c.strip()
        if len(t) < 35 or len(t) > 360:
            continue
        if not _KEYWORD_RE.search(t):
            continue
        key = t.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(t)
        if len(out) >= limit:
            break
    return out


def _site_channel_id(url: str) -> int:
    digest = hashlib.sha1(url.encode("utf-8")).hexdigest()[:12]
    return -int(digest, 16)


def _message_id(url: str, text: str) -> int:
    digest = hashlib.sha1(f"{url}|{text}".encode("utf-8")).hexdigest()[:10]
    return int(digest, 16)


async def run_site_ingest_loop(bot: Bot, site_urls: tuple[str, ...], poll_seconds: int = 900) -> None:
    urls = tuple(u.strip() for u in site_urls if u.strip())
    if not urls:
        return
    log.info("Logistika sayt ingest yoqildi: %s ta manba", len(urls))
    while True:
        for url in urls:
            try:
                parsed = urlparse(url)
                domain = parsed.netloc or "site"
                page_html = await asyncio.to_thread(_download_html, url)
                candidates = _extract_candidates(page_html)
                for text in candidates:
                    cid = _site_channel_id(url)
                    mid = _message_id(url, text)
                    lid = await db.insert_channel_listing(
                        channel_id=cid,
                        message_id=mid,
                        channel_username=domain,
                        channel_title=f"Logistics site: {domain}",
                        body=text,
                        posted_at=None,
                    )
                    if lid is None:
                        continue
                    _, cargo_ids = await save_logistics_from_text(user_id=cid, text=text)
                    for cargo_id in cargo_ids[:50]:
                        asyncio.create_task(push_cargo_to_seekers(bot, cargo_id))
                if candidates:
                    log.info("Logistika sayt parse: %s — %s ta kandidat", domain, len(candidates))
            except Exception as e:
                log.warning("Logistika sayt parse xato: %s (%s)", url, e)
            await asyncio.sleep(0.15)
        await asyncio.sleep(max(120, poll_seconds))
