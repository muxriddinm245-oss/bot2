from __future__ import annotations

import hashlib
import re

from app import db
from app.matching import body_hints_logistics_cargo

_CARGO_TERMS = (
    "yuk bor",
    "yuk kerak",
    "yuk qidir",
    "yuk top",
    "yuk izlash",
    "yuk ol",
    "yuk ",
    "yuk\n",
    "yuk,",
    "yuk.",
    "yuk/",
    "юк",
    "груз",
    "gruz",
    "cargo",
    "fura kerak",
    "mashina kerak",
    "moshina kerak",
    "достав",
    "перевоз",
    "perevoz",
)
_VEHICLE_TERMS = (
    "moshina bor",
    "mashina bor",
    "fura bor",
    "isuzu bor",
    "damas bor",
    "transport bor",
    "driver bor",
)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def _dedup_key(kind: str, text: str) -> str:
    base = f"{kind}|{_norm(text)}"
    return hashlib.sha1(base.encode("utf-8")).hexdigest()


def _extract_contact(text: str) -> str:
    phone = re.search(r"(\+?\d[\d\s\-\(\)]{7,}\d)", text)
    if phone:
        return phone.group(1).strip()
    username = re.search(r"(@[A-Za-z0-9_]{4,})", text)
    if username:
        return username.group(1)
    return ""


def _extract_route(text: str) -> tuple[str, str]:
    # "A -> B" yoki "A - B" formatlarini ushlaydi
    m = re.search(r"([A-Za-zА-Яа-яЎўҚқҒғҲҳ0-9\s']{2,40})\s*(?:->|=>|—|–|-)\s*([A-Za-zА-Яа-яЎўҚқҒғҲҳ0-9\s']{2,40})", text)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    # "X dan Y ga" ko'rinishidagi sodda holat
    m2 = re.search(r"([A-Za-zА-Яа-яЎўҚқҒғҲҳ0-9\s']{2,40})\s+dan\s+([A-Za-zА-Яа-яЎўҚқҒғҲҳ0-9\s']{2,40})\s+ga", text.lower())
    if m2:
        return m2.group(1).strip().title(), m2.group(2).strip().title()
    return "", ""


def _looks_like_cargo(text: str) -> bool:
    if body_hints_logistics_cargo(text):
        return True
    n = _norm(text)
    return any(t in n for t in _CARGO_TERMS)


def _looks_like_vehicle(text: str) -> bool:
    n = _norm(text)
    return any(t in n for t in _VEHICLE_TERMS)


async def save_logistics_from_text(user_id: int, text: str) -> tuple[bool, list[int]]:
    raw = (text or "").strip()
    if not raw:
        return False
    contact = _extract_contact(raw)
    from_city, to_city = _extract_route(raw)
    saved = False
    cargo_ids: list[int] = []

    if _looks_like_cargo(raw):
        if await db.register_logistics_seen(_dedup_key("cargo", raw)):
            rid = await db.insert_logistics_cargo(
                user_id=user_id,
                from_city=from_city or "Noma'lum",
                to_city=to_city or "Noma'lum",
                cargo_type=raw[:200],
                weight="",
                contact=contact or "ko'rsatilmagan",
            )
            cargo_ids.append(int(rid))
            saved = True

    if _looks_like_vehicle(raw):
        if await db.register_logistics_seen(_dedup_key("vehicle", raw)):
            await db.insert_logistics_vehicle(
                user_id=user_id,
                from_city=from_city or "Noma'lum",
                to_city=to_city or "Noma'lum",
                vehicle_type=raw[:200],
                capacity="",
                contact=contact or "ko'rsatilmagan",
            )
            saved = True

    return saved, cargo_ids
