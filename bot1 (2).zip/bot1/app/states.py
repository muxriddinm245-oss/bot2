from aiogram.fsm.state import State, StatesGroup


class SeekerProfile(StatesGroup):
    city = State()
    direction = State()
    contact = State()


class EmployerProfile(StatesGroup):
    company = State()


class NewJob(StatesGroup):
    title = State()
    description = State()
    city = State()
    direction = State()
    salary = State()
    contact = State()


class ServiceRequest(StatesGroup):
    service_type = State()
    details = State()
    contact = State()


class AdPaymentProof(StatesGroup):
    photo = State()


class AdCreativeSubmission(StatesGroup):
    text = State()


class AiChat(StatesGroup):
    question = State()


class LogisticsType(StatesGroup):
    kind = State()


class LogisticsCargo(StatesGroup):
    from_city = State()
    to_city = State()
    cargo_type = State()
    weight = State()
    contact = State()


class LogisticsVehicle(StatesGroup):
    from_city = State()
    to_city = State()
    vehicle_type = State()
    capacity = State()
    contact = State()
