"""Kanal matnida shahar / yo‘nalish qidiruvchi profiliga mos kelishini tekshirish."""

import re
import unicodedata

# Shahar nomlari turli yozilishda uchraydi
_CITY_GROUPS: list[tuple[str, ...]] = [
    ("toshkent", "ташкент", "tashkent"),
    ("samarqand", "самарканд", "samarkand"),
    ("buxoro", "бухоро", "bukhara"),
    ("andijon", "андижан", "andijan"),
    ("namangan", "наманган"),
    ("farg'ona", "fargona", "фергана", "fergana"),
    ("qarshi", "qashqadaryo", "қашқадарё"),
    ("termiz", "surxondaryo", "сурхондарё"),
    ("navoiy", "навои", "navoi"),
    ("jizzax", "jizax", "jizzah", "джизак", "джиззах", "jizzakh"),
    ("guliston", "sirdaryo", "сирдарё"),
    ("urganch", "xorazm", "xorzm", "xarazm", "horazm", "khorezm", "хоразм", "хорезм", "xiva"),
    ("nukus", "qoraqalpoq", "қорақалпоқ"),
    ("chirchiq", "angren", "bekobod", "oqqo‘rg‘on", "toshkent vil"),
]

_ANYWHERE_CITY = {
    "farqi yo'q",
    "farqi yoq",
    "farqi yuq",
    "qayer bo'lsa ham",
    "qayer bolsa ham",
    "qayerda bolsa ham",
    "hamma joy",
    "istalgan joy",
    "uzbekiston",
    "o'zbekiston",
    "ozbekiston",
    "online",
    "onlayn",
    "remote",
    "masofaviy",
    "uyda",
    "uydan",
}

_DIRECTION_GROUPS: list[tuple[str, ...]] = [
    (
        "sotuvchi",
        "sotuv",
        "sotish",
        "sotuvlar",
        "savdo",
        "savdoga",
        "savdolar",
        "savdo agent",
        "savdo agenti",
        "savdo vakili",
        "savdo menejeri",
        "savdo konsultanti",
        "sotuv agenti",
        "sotuv menejeri",
        "sotuvchi kassir",
        "sotuvchi-kassir",
        "agent",
        "aget",
        "mijozlar bilan ishlash",
        "mijoz",
        "sales",
        "seller",
        "sales agent",
        "sales manager",
        "sales representative",
        "torgoviy",
        "torgovy",
        "торговый",
        "продавец",
        "кассир",
        "консультант",
        "представитель",
        "kassir",
        "konsultant",
        "maslahatchi",
        "merchandiser",
        "promouter",
        "market",
        "supermarket",
        "do'kon",
        "dukon",
        "magazin",
    ),
    (
        "it",
        "it soha",
        "it sohasi",
        "itga",
        "it mutaxassis",
        "ayti",
        "ayti soha",
        "айти",
        "dasturchi",
        "dasturlash",
        "dastur",
        "programmist",
        "программист",
        "programmer",
        "programming",
        "developer",
        "dev",
        "разработчик",
        "engineer",
        "инженер",
        "software",
        "web",
        "web developer",
        "data",
        "dataengineer",
        "data engineer",
        "data analyst",
        "analitik",
        "analyst",
        "sql",
        "snowflake",
        "python",
        "javascript",
        "java",
        "react",
        "flutter",
        "golang",
        "node",
        "frontend",
        "front-end",
        "backend",
        "back-end",
        "fullstack",
        "full stack",
        "devops",
        "qa",
        "tester",
        "testировщик",
        "testirovshik",
        "ui",
        "ux",
        "designer",
        "grafik dizayner",
        "smm",
        "targetolog",
        "marketing",
        "digital",
        "kompyuter",
        "computer",
        "texnik",
        "texnik yordam",
        "technical support",
        "support engineer",
        "sysadmin",
        "sistem administrator",
        "системный администратор",
        "admin it",
        "crm",
        "1c dasturchi",
        "bitrix",
        "wordpress",
        "figma",
        "android",
        "ios",
        "mobile developer",
        "bot",
    ),
    (
        "haydovchi",
        "haydovchilik",
        "haydochi",
        "haydochilik",
        "driver",
        "voditel",
        "водитель",
        "kuryer",
        "avtokuryer",
        "yetkazib berish",
        "dostavka",
        "logistika",
        "ekspeditor",
        "taxi",
        "taksi",
        "yuk tashish",
        "yuk mashina",
        "yuk mashinasi",
        "avto",
        "avtomobil",
        "avtobus",
        "kamaz",
        "tirkama",
        "b c",
        "b kategoriya",
        "c kategoriya",
    ),
    (
        "oshpaz",
        "povar",
        "повар",
        "kafe",
        "кафе",
        "restoran",
        "ресторан",
        "ofitsiant",
        "официант",
        "barista",
        "barmen",
        "fast food",
        "oshxona",
        "kuhniya",
        "кухня",
        "salatchi",
        "mangal",
        "shashlik",
        "nonvoy",
        "pishiriq",
        "konditer",
        "konditerlik",
        "konditerka",
        "qandolat",
    ),
    (
        "ombor",
        "sklad",
        "склад",
        "skladchi",
        "omborchi",
        "yukchi",
        "gruzchik",
        "грузчик",
        "qadoqlash",
        "qadoqlovchi",
        "upakovka",
        "упаковка",
        "komplektovchi",
        "sortirovka",
        "kladovshik",
        "кладовщик",
        "logistika ombor",
        "sklad operatori",
        "ombor operatori",
    ),
    (
        "logistika",
        "logist",
        "logistka",
        "logistic",
        "logistics",
        "logistics specialist",
        "logistics manager",
        "transport logistikasi",
        "ta'minot zanjiri",
        "supply chain",
        "supply chain specialist",
        "supply chain manager",
        "procurement",
        "xarid",
        "ta'minot",
        "zakupka",
        "закупка",
        "dispecher",
        "dispetcher logist",
        "диспетчер",
        "shipment",
        "shipping",
        "yuklarni rejalashtirish",
        "import",
        "eksport",
        "export",
        "broker",
        "bojxona",
        "customs",
        "fleet manager",
    ),
    (
        "tikuvchi",
        "tikuv",
        "chevar",
        "seamstress",
        "textile",
        "tekstil",
        "to'qimachilik",
        "toquv",
        "shveya",
        "швея",
        "zakroyshik",
        "bichuvchi",
        "dazmolchi",
        "dazmol",
        "press",
        "overlok",
    ),
    (
        "quruvchi",
        "qurilish",
        "стройка",
        "строитель",
        "usta",
        "remont",
        "ta'mir",
        "santexnik",
        "santexnika",
        "elektrik",
        "payvandchi",
        "svarchik",
        "сварщик",
        "malyar",
        "gips",
        "gipsokarton",
        "beton",
        "suvoq",
        "kafel",
        "plitka",
        "montaj",
    ),
    (
        "tozalovchi",
        "tozalash",
        "uborka",
        "уборка",
        "farrosh",
        "cleaner",
        "klining",
        "cleaning",
        "sanitarka",
        "posudamoyka",
        "idish yuvuvchi",
        "kir yuvish",
        "xona xizmatchisi",
    ),
    (
        "admin",
        "administrator",
        "администратор",
        "menejer",
        "manager",
        "ofis",
        "ofis menedjer",
        "yordamchi",
        "assistant",
        "assistent",
        "sekretar",
        "kotiba",
        "qabulxona",
        "reception",
        "resepshn",
    ),
    (
        "operator",
        "call center",
        "call-markaz",
        "call markaz",
        "koll sentr",
        "колл центр",
        "aloqa markazi",
        "telefon operator",
        "dispetcher",
        "mijozlarga xizmat",
        "support",
        "qo'ng'iroq",
        "zvonok",
        "чат оператор",
        "chat operator",
    ),
    (
        "buxgalter",
        "buxgalteriya",
        "accountant",
        "accounting",
        "бухгалтер",
        "kassir buxgalter",
        "moliyachi",
        "finance",
        "moliya",
        "hisobchi",
        "1c",
        "soliq",
        "audit",
    ),
    (
        "hr",
        "rekruter",
        "recruiter",
        "kadr",
        "кадр",
        "xodimlar",
        "personal",
        "персонал",
        "ishga qabul",
        "kadrovik",
    ),
    (
        "ta'lim",
        "talim",
        "o'qituvchi",
        "oqituvchi",
        "ustoz",
        "teacher",
        "prepodavatel",
        "преподаватель",
        "tarbiyachi",
        "repetitor",
        "mentor",
        "trener",
        "kurs",
        "maktab",
        "bog'cha",
        "детский сад",
    ),
    (
        "tibbiyot",
        "meditsina",
        "medicina",
        "medical",
        "врач",
        "shifokor",
        "hamshira",
        "medsestra",
        "медсестра",
        "klinika",
        "apteka",
        "farmatsevt",
        "laborant",
        "stomatolog",
        "doktor",
    ),
    (
        "qorovul",
        "qo'riqchi",
        "qoriqchi",
        "oxrana",
        "охранник",
        "security",
        "nazorat",
        "nazoratchi",
        "xavfsizlik",
    ),
    (
        "go'zallik",
        "gozallik",
        "beauty",
        "salon",
        "sartarosh",
        "barber",
        "parikmaxer",
        "парикмахер",
        "kosmetolog",
        "визажист",
        "makeup",
        "manikyur",
        "pedikyur",
        "massaj",
        "massajist",
    ),
    (
        "dehqon",
        "dexqon",
        "dehkon",
        "fermer",
        "agro",
        "agronom",
        "qishloq xo'jaligi",
        "qishloq xojaligi",
        "dala",
        "bog'",
        "bogbon",
        "bog'bon",
        "issiqxona",
        "issiqhona",
        "теплица",
        "suvorish",
        "chorva",
        "chorvachilik",
        "mol boqish",
        "parranda",
        "tomorqa",
        "traktor",
        "traktorchi",
        "парник",
    ),
    (
        "onlayn ish",
        "onlayn",
        "onlayn ishlash",
        "online ish",
        "online",
        "masofaviy ish",
        "masofaviy bandlik",
        "remote ish",
        "remote",
        "uydan ishlash",
        "uyda ish",
        "uyda",
        "distantsion",
        "distantsion ish",
        "internet orqali ish",
        "internet ish",
        "internetda ish",
        "freelance",
        "frilans",
        "фриланс",
        "фрилансер",
        "digital nomad",
        "kopirayter",
        "copywriter",
        "kontent menejer",
        "kontent-maker",
        "onlayn operator",
        "onlayn mentor",
        "zoom",
        "telegram orqali ish",
    ),
    (
        "kunlik ish",
        "kunlik",
        "har kungi ish",
        "har kungi",
        "podrabotka",
        "podrabotka ish",
        "vaqtincha ish",
        "vaqtinchalik ish",
        "vaqtinchalik bandlik",
        "bir kunlik ish",
        "bir kunlik",
        "smenali ish",
        "smena ish",
        "smena",
        "smena boyicha",
        "qisqa muddatli ish",
        "qisqa muddat",
        "kuniga to'lov",
        "kuniga tolov",
        "to'lov kuniga",
        "tolov kuniga",
        "soatbay ish",
        "ish haqi kuniga",
        "разовая работа",
        "разовый подработка",
        "подработка",
        "ежедневная оплата",
        "оплата за день",
        "daily work",
        "gig work",
        "vaqtinchalik qabul",
        "mavsumiy ish",
    ),
]


def normalize(s: str) -> str:
    if not s:
        return ""
    s = unicodedata.normalize("NFKC", s)
    s = s.lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s


def guess_city_from_user_text(text: str) -> str:
    """Foydalanuvchi xabaridan shahar (yoki viloyat markazi) taxmin qiladi."""
    h = normalize(text)
    if not h:
        return ""
    for group in _CITY_GROUPS:
        for variant in group:
            v = normalize(variant)
            if len(v) >= 3 and v in h:
                base = group[0]
                if not base:
                    return ""
                return base[:1].upper() + base[1:]
    return ""


def _city_needles(user_city: str) -> set[str]:
    """Foydalanuvchi kiritgan shahar uchun qidiriladigan qatorlar."""
    u = normalize(user_city)
    if not u:
        return set()
    needles = {u}
    for group in _CITY_GROUPS:
        norms = {normalize(x) for x in group}
        if any(u in g or g in u for g in norms if g):
            needles.update(x for x in norms if len(x) >= 2)
    return needles


def wants_any_city(city: str) -> bool:
    u = normalize(city)
    if not u:
        return True
    return any(term in u or u in term for term in _ANYWHERE_CITY) or looks_like_direction(u)


def looks_like_direction(value: str) -> bool:
    v = normalize(value)
    if not v:
        return False
    for group in _DIRECTION_GROUPS:
        norms = {normalize(x) for x in group}
        if any(v in g or g in v for g in norms if g):
            return True
    return False


def text_matches_city(body: str, city: str) -> bool:
    h = normalize(body)
    if not h:
        return False
    for needle in _city_needles(city):
        if needle and needle in h:
            return True
    return False


def _contains_term(haystack: str, term: str) -> bool:
    term = normalize(term)
    if not term:
        return False
    if len(term) <= 3 and re.fullmatch(r"[a-z0-9а-яё]+", term):
        return re.search(rf"(?<![a-z0-9а-яё]){re.escape(term)}(?![a-z0-9а-яё])", haystack) is not None
    return term in haystack


def text_matches_direction(body: str, direction: str) -> bool:
    d = normalize(direction)
    if not d or len(d) < 2:
        return True
    h = normalize(body)
    if _contains_term(h, d):
        return True
    for group in _DIRECTION_GROUPS:
        norms = {normalize(x) for x in group}
        if any(d in g or g in d for g in norms if g):
            return any(_contains_term(h, g) for g in norms)
    return False


def direction_match_score(body: str, direction: str) -> int:
    d = normalize(direction)
    if not d:
        return 0
    h = normalize(body)
    if _contains_term(h, d):
        return 20
    for group in _DIRECTION_GROUPS:
        norms = {normalize(x) for x in group}
        if any(d in g or g in d for g in norms if g):
            for term in norms:
                if _contains_term(h, term):
                    return 12
    return 0


def body_hints_logistics_cargo(body: str) -> bool:
    """Yuk/logistika e'lonimi — profil boshqa sohada bo'lsa ham Mos yuklar topish uchun."""
    h = normalize(body)
    if not h:
        return False
    short = ("yuk", "юк")
    for term in short:
        if _contains_term(h, term):
            return True
    for term in (
        "gruz",
        "груз",
        "cargo",
        "logistika",
        "fura",
        "tirkama",
        "marshrut",
        "tashish",
        "perevoz",
        "достав",
        "перевоз",
        "truck",
        "konteiner",
    ):
        if term in h:
            return True
    if ("moshina" in h or "mashina" in h) and any(
        k in h for k in ("bor", "kerak", "qidir", "qidiry", "kerak edi")
    ):
        return True
    return False


def matches_seeker_profile(body: str, city: str, direction: str) -> bool:
    city = (city or "").strip()
    direction = (direction or "").strip()
    if not wants_any_city(city) and not text_matches_city(body, city):
        return False
    if direction and not text_matches_direction(body, direction):
        return False
    return bool(direction or city)
