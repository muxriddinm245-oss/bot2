from __future__ import annotations

import asyncio
import html
import logging

from aiogram import Bot

from app import db
from app.ai_matcher import match_cargo_to_seeker
from app.config import get_settings
from app.matching import direction_match_score, text_matches_city, wants_any_city

log = logging.getLogger(__name__)


def _cargo_message(row: dict) -> str:
    route = f"{html.escape(row.get('from_city') or '—')} → {html.escape(row.get('to_city') or '—')}"
    cargo_type = html.escape(row.get("cargo_type") or "Yuk")
    weight = f"\nYuk/og'irlik: {html.escape(row.get('weight') or '—')}" if row.get("weight") else ""
    contact = f"\nAloqa: {html.escape(row.get('contact') or '—')}"
    return (
        f"🚚 <b>Yangi mos yuk e’loni</b> #{row['id']}\n"
        f"Yo'nalish: {route}\n"
        f"Yuk: {cargo_type}{weight}{contact}\n"
        "—\n"
        "<i>Sizning profilingizga mos deb topildi.</i>"
    )


async def push_cargo_to_seekers(
    bot: Bot,
    cargo_id: int,
    *,
    exclude_user_id: int | None = None,
) -> int:
    row = await db.get_logistics_cargo(cargo_id)
    if not row:
        return 0
    if (row.get("status") or "new").strip().lower() != "new":
        return 0
    seekers = await db.list_seekers_for_logistics_push()
    settings = get_settings()
    sent = 0
    from_city = (row.get("from_city") or "").strip()
    to_city = (row.get("to_city") or "").strip()
    route = f"{from_city} {to_city}".strip()
    body = f"{row.get('cargo_type') or ''} {route}"
    unknown_route = (not route) or ("noma" in route.lower())
    msg = _cargo_message(row)
    cargo_summary = " | ".join(
        p
        for p in (
            f"{from_city} → {to_city}".strip(),
            (row.get("cargo_type") or "").strip(),
            (row.get("weight") or "").strip(),
            (row.get("contact") or "").strip(),
        )
        if p
    )
    ai_enabled = settings.ai_match_enabled and bool(settings.gemini_api_key.strip())
    ai_direction_cache: dict[str, tuple[bool, int] | None] = {}

    for s in seekers:
        if sent >= settings.max_push_per_post:
            break
        uid = int(s.get("user_id") or 0)
        if uid <= 0:
            continue
        if exclude_user_id and uid == int(exclude_user_id):
            continue
        city = (s.get("city") or "").strip()
        direction = (s.get("direction") or "").strip()
        city_ok = wants_any_city(city) or text_matches_city(route, city) or unknown_route
        if not city_ok:
            continue
        if direction:
            rule_score = direction_match_score(body, direction)
            if ai_enabled:
                cache_key = direction.lower()
                ai_decision = ai_direction_cache.get(cache_key)
                if ai_decision is None and cache_key not in ai_direction_cache:
                    result = await match_cargo_to_seeker(
                        api_key=settings.gemini_api_key,
                        model=settings.gemini_model,
                        cargo_summary=cargo_summary or body,
                        seeker_city=city,
                        seeker_direction=direction,
                    )
                    if result is None:
                        ai_direction_cache[cache_key] = None
                    else:
                        ai_direction_cache[cache_key] = (result.match, result.score)
                    ai_decision = ai_direction_cache.get(cache_key)
                if ai_decision is None:
                    if rule_score <= 0:
                        continue
                else:
                    is_match, ai_score = ai_decision
                    if (not is_match) or ai_score < settings.ai_match_min_score:
                        continue
            elif rule_score <= 0:
                continue
        if await db.was_logistics_push_sent(cargo_id, uid):
            continue
        try:
            await bot.send_message(uid, msg, parse_mode="HTML", disable_web_page_preview=True)
            await db.mark_logistics_push_sent(cargo_id, uid)
            sent += 1
        except Exception as e:
            log.debug("Yuk push yuborilmadi: cargo=%s user=%s err=%s", cargo_id, uid, e)
        await asyncio.sleep(0.03)
    return sent

