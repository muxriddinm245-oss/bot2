from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

def _auto_test_button() -> KeyboardButton:
    return KeyboardButton(text="🚗 Avto test mini-ilova")


def _chet_el_ish_button() -> KeyboardButton:
    return KeyboardButton(text="🌍 Chet eldan ish")


def _talabalar_uchun_button() -> KeyboardButton:
    return KeyboardButton(text="🎓 Talabalar uchun")


def _tanishuv_button() -> KeyboardButton:
    return KeyboardButton(text="💬 Tanishuv")


def _coming_soon_row() -> list[KeyboardButton]:
    return [_auto_test_button(), _chet_el_ish_button()]


def _coming_soon_row2() -> list[KeyboardButton]:
    return [_talabalar_uchun_button(), _tanishuv_button()]


def _with_admin_row(rows: list[list[KeyboardButton]], is_admin: bool = False) -> list[list[KeyboardButton]]:
    if is_admin:
        rows.append([KeyboardButton(text="⚙️ Admin menu")])
    return rows


def role_keyboard(is_admin: bool = False) -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=_with_admin_row(
            [
                [
                    KeyboardButton(text="🚚 Logistika: Yuk bor / Moshina bor"),
                    KeyboardButton(text="🤖 AI yordam"),
                ],
                _coming_soon_row(),
                _coming_soon_row2(),
                [KeyboardButton(text="Ish qidiruvchi"), KeyboardButton(text="Ish beruvchi")],
                [
                    KeyboardButton(text="💡 Sayt/Ilova/Bot buyurtma"),
                    KeyboardButton(text="📢 Reklama berish"),
                ],
                [KeyboardButton(text="📣 Ishchi kanallar topish")],
            ],
            is_admin,
        ),
        resize_keyboard=True,
    )


def main_seeker_kb(is_admin: bool = False) -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=_with_admin_row(
            [
                [
                    KeyboardButton(text="🚚 Logistika: Yuk bor / Moshina bor"),
                    KeyboardButton(text="🤖 AI yordam"),
                ],
                _coming_soon_row(),
                _coming_soon_row2(),
                [KeyboardButton(text="Mos ishlar"), KeyboardButton(text="Mos yuklar")],
                [KeyboardButton(text="Profilimni yangilash")],
                [KeyboardButton(text="📣 Avtomatik xabarlar"), KeyboardButton(text="🚚 Yuk alertlar")],
                [
                    KeyboardButton(text="💡 Sayt/Ilova/Bot buyurtma"),
                    KeyboardButton(text="📢 Reklama berish"),
                ],
                [KeyboardButton(text="📣 Ishchi kanallar topish")],
                [KeyboardButton(text="Rolni o‘zgartirish")],
            ],
            is_admin,
        ),
        resize_keyboard=True,
    )


def main_employer_kb(is_admin: bool = False) -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=_with_admin_row(
            [
                [
                    KeyboardButton(text="🚚 Logistika: Yuk bor / Moshina bor"),
                    KeyboardButton(text="🤖 AI yordam"),
                ],
                _coming_soon_row(),
                _coming_soon_row2(),
                [KeyboardButton(text="Yangi vakansiya"), KeyboardButton(text="Kompaniyam")],
                [KeyboardButton(text="Mos ishchilar")],
                [
                    KeyboardButton(text="💡 Sayt/Ilova/Bot buyurtma"),
                    KeyboardButton(text="📢 Reklama berish"),
                ],
                [KeyboardButton(text="📣 Ishchi kanallar topish")],
                [KeyboardButton(text="Rolni o‘zgartirish")],
            ],
            is_admin,
        ),
        resize_keyboard=True,
    )


def cancel_inline() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="Bekor qilish", callback_data="cancel_fsm")]]
    )
