import aiosqlite
from pathlib import Path

from app.matching import (
    body_hints_logistics_cargo,
    direction_match_score,
    text_matches_city,
    wants_any_city,
)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
CORE_DB_PATH = DATA_DIR / "core.db"
CHANNEL_DB_PATH = DATA_DIR / "channels.db"
SERVICE_DB_PATH = DATA_DIR / "services.db"
LOGISTICS_DB_PATH = DATA_DIR / "logistics.db"
LEGACY_DB_PATH = DATA_DIR / "jobs.db"


async def _table_exists(db: aiosqlite.Connection, table_name: str) -> bool:
    cur = await db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name = ?",
        (table_name,),
    )
    return await cur.fetchone() is not None


async def _table_row_count(db: aiosqlite.Connection, table_name: str) -> int:
    cur = await db.execute(f"SELECT COUNT(*) FROM {table_name}")
    row = await cur.fetchone()
    return int(row[0] if row else 0)


async def _table_columns(db: aiosqlite.Connection, table_name: str) -> set[str]:
    cur = await db.execute(f"PRAGMA table_info({table_name})")
    rows = await cur.fetchall()
    return {str(r[1]) for r in rows}


async def _copy_table_if_needed(
    source: aiosqlite.Connection,
    target: aiosqlite.Connection,
    table_name: str,
    columns: tuple[str, ...],
) -> None:
    if not await _table_exists(source, table_name):
        return
    if not await _table_exists(target, table_name):
        return
    if await _table_row_count(target, table_name) > 0:
        return
    src_cols = await _table_columns(source, table_name)
    tgt_cols = await _table_columns(target, table_name)
    copy_cols = [c for c in columns if c in src_cols and c in tgt_cols]
    if not copy_cols:
        return
    cols = ", ".join(copy_cols)
    placeholders = ", ".join("?" for _ in copy_cols)
    cur = await source.execute(f"SELECT {cols} FROM {table_name}")
    rows = await cur.fetchall()
    if not rows:
        return
    await target.executemany(
        f"INSERT OR IGNORE INTO {table_name} ({cols}) VALUES ({placeholders})",
        rows,
    )


async def _migrate_core(db: aiosqlite.Connection) -> None:
    cur = await db.execute("PRAGMA table_info(users)")
    cols = {row[1] for row in await cur.fetchall()}
    if "notify_channels" not in cols:
        await db.execute(
            "ALTER TABLE users ADD COLUMN notify_channels INTEGER NOT NULL DEFAULT 1"
        )
    if "notify_logistics" not in cols:
        await db.execute(
            "ALTER TABLE users ADD COLUMN notify_logistics INTEGER NOT NULL DEFAULT 1"
        )
    if "contact" not in cols:
        await db.execute("ALTER TABLE users ADD COLUMN contact TEXT NOT NULL DEFAULT ''")
    cur = await db.execute("PRAGMA table_info(jobs)")
    job_cols = {row[1] for row in await cur.fetchall()}
    if "contact" not in job_cols:
        await db.execute("ALTER TABLE jobs ADD COLUMN contact TEXT NOT NULL DEFAULT ''")


async def _migrate_channels(db: aiosqlite.Connection) -> None:
    cur = await db.execute("PRAGMA table_info(channel_listings)")
    cols = {row[1] for row in await cur.fetchall()}
    if "posted_at" not in cols:
        await db.execute("ALTER TABLE channel_listings ADD COLUMN posted_at TEXT")


async def _migrate_services(db: aiosqlite.Connection) -> None:
    cur = await db.execute("PRAGMA table_info(service_requests)")
    cols = {row[1] for row in await cur.fetchall()}
    if "payment_proof_file_id" not in cols:
        await db.execute(
            "ALTER TABLE service_requests ADD COLUMN payment_proof_file_id TEXT NOT NULL DEFAULT ''"
        )
    if "payment_submitted_at" not in cols:
        await db.execute("ALTER TABLE service_requests ADD COLUMN payment_submitted_at TEXT")


async def _migrate_from_legacy_if_needed() -> None:
    if not LEGACY_DB_PATH.exists():
        return
    # Agar eski fayl yangi core faylga teng bo'lsa, split migratsiya o'tkazilmaydi.
    if LEGACY_DB_PATH.resolve() == CORE_DB_PATH.resolve():
        return

    async with (
        aiosqlite.connect(LEGACY_DB_PATH) as src,
        aiosqlite.connect(CORE_DB_PATH) as core,
        aiosqlite.connect(CHANNEL_DB_PATH) as channels,
        aiosqlite.connect(SERVICE_DB_PATH) as services,
        aiosqlite.connect(LOGISTICS_DB_PATH) as logistics,
    ):
        await _copy_table_if_needed(
            src,
            core,
            "users",
            (
                "user_id",
                "role",
                "city",
                "direction",
                "company_name",
                "contact",
                "created_at",
                "notify_channels",
                "notify_logistics",
            ),
        )
        await _copy_table_if_needed(
            src,
            core,
            "jobs",
            (
                "id",
                "employer_id",
                "title",
                "description",
                "city",
                "direction",
                "salary",
                "contact",
                "is_active",
                "created_at",
            ),
        )
        await _copy_table_if_needed(
            src,
            channels,
            "channel_listings",
            (
                "id",
                "channel_id",
                "message_id",
                "channel_username",
                "channel_title",
                "body",
                "posted_at",
                "created_at",
            ),
        )
        await _copy_table_if_needed(
            src,
            channels,
            "channel_push_sent",
            ("listing_id", "user_id", "created_at"),
        )
        await _copy_table_if_needed(
            src,
            services,
            "service_requests",
            (
                "id",
                "user_id",
                "service_type",
                "details",
                "contact",
                "status",
                "created_at",
                "payment_proof_file_id",
                "payment_submitted_at",
            ),
        )
        await _copy_table_if_needed(
            src,
            logistics,
            "logistics_cargo",
            (
                "id",
                "user_id",
                "from_city",
                "to_city",
                "cargo_type",
                "weight",
                "contact",
                "status",
                "created_at",
            ),
        )
        await _copy_table_if_needed(
            src,
            logistics,
            "logistics_vehicle",
            (
                "id",
                "user_id",
                "from_city",
                "to_city",
                "vehicle_type",
                "capacity",
                "contact",
                "status",
                "created_at",
            ),
        )
        await core.commit()
        await channels.commit()
        await services.commit()
        await logistics.commit()


async def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    async with aiosqlite.connect(CORE_DB_PATH) as db:
        await db.executescript(
            """
            PRAGMA foreign_keys = ON;

            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                role TEXT NOT NULL CHECK(role IN ('seeker','employer')),
                city TEXT NOT NULL DEFAULT '',
                direction TEXT NOT NULL DEFAULT '',
                company_name TEXT NOT NULL DEFAULT '',
                contact TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT (datetime('now')),
                notify_channels INTEGER NOT NULL DEFAULT 1,
                notify_logistics INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employer_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                city TEXT NOT NULL,
                direction TEXT NOT NULL DEFAULT '',
                salary TEXT NOT NULL DEFAULT '',
                contact TEXT NOT NULL DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY (employer_id) REFERENCES users(user_id)
            );

            CREATE INDEX IF NOT EXISTS idx_jobs_city ON jobs(city);
            CREATE INDEX IF NOT EXISTS idx_jobs_direction ON jobs(direction);
            CREATE INDEX IF NOT EXISTS idx_jobs_active ON jobs(is_active);
            """
        )
        await _migrate_core(db)
        await db.commit()

    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        await db.executescript(
            """
            PRAGMA foreign_keys = ON;

            CREATE TABLE IF NOT EXISTS channel_listings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL,
                channel_username TEXT NOT NULL DEFAULT '',
                channel_title TEXT NOT NULL DEFAULT '',
                body TEXT NOT NULL,
                posted_at TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                UNIQUE(channel_id, message_id)
            );

            CREATE INDEX IF NOT EXISTS idx_channel_listings_id ON channel_listings(id);

            CREATE TABLE IF NOT EXISTS channel_push_sent (
                listing_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                created_at TEXT DEFAULT (datetime('now')),
                PRIMARY KEY (listing_id, user_id),
                FOREIGN KEY (listing_id) REFERENCES channel_listings(id)
            );

            CREATE TABLE IF NOT EXISTS discovered_sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_type TEXT NOT NULL CHECK(source_type IN ('channel','site')),
                source_key TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
                confidence INTEGER NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT '',
                first_seen_at TEXT DEFAULT (datetime('now')),
                last_seen_at TEXT DEFAULT (datetime('now')),
                approved_at TEXT,
                UNIQUE(source_type, source_key)
            );
            CREATE INDEX IF NOT EXISTS idx_discovered_sources_status
                ON discovered_sources(status, source_type, id DESC);
            """
        )
        await _migrate_channels(db)
        await db.commit()

    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS service_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                service_type TEXT NOT NULL,
                details TEXT NOT NULL,
                contact TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'new',
                payment_proof_file_id TEXT NOT NULL DEFAULT '',
                payment_submitted_at TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_service_requests_created
                ON service_requests(id DESC);

            CREATE TABLE IF NOT EXISTS app_config (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT '',
                updated_at TEXT DEFAULT (datetime('now'))
            );
            """
        )
        await _migrate_services(db)
        await db.commit()

    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS logistics_cargo (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                from_city TEXT NOT NULL,
                to_city TEXT NOT NULL,
                cargo_type TEXT NOT NULL,
                weight TEXT NOT NULL DEFAULT '',
                contact TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'new',
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS logistics_vehicle (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                from_city TEXT NOT NULL,
                to_city TEXT NOT NULL,
                vehicle_type TEXT NOT NULL,
                capacity TEXT NOT NULL DEFAULT '',
                contact TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'new',
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE INDEX IF NOT EXISTS idx_logistics_cargo_created
                ON logistics_cargo(id DESC);
            CREATE INDEX IF NOT EXISTS idx_logistics_vehicle_created
                ON logistics_vehicle(id DESC);

            CREATE TABLE IF NOT EXISTS logistics_seen (
                key TEXT PRIMARY KEY,
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE TABLE IF NOT EXISTS logistics_push_sent (
                cargo_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                created_at TEXT DEFAULT (datetime('now')),
                PRIMARY KEY (cargo_id, user_id)
            );
            CREATE INDEX IF NOT EXISTS idx_logistics_push_sent_user
                ON logistics_push_sent(user_id, cargo_id DESC);

            CREATE TABLE IF NOT EXISTS logistics_status_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cargo_id INTEGER NOT NULL,
                old_status TEXT NOT NULL,
                new_status TEXT NOT NULL,
                changed_by INTEGER NOT NULL,
                note TEXT NOT NULL DEFAULT '',
                created_at TEXT DEFAULT (datetime('now'))
            );
            CREATE INDEX IF NOT EXISTS idx_logistics_status_history_cargo
                ON logistics_status_history(cargo_id, id DESC);
            """
        )
        await db.commit()

    await _migrate_from_legacy_if_needed()


async def get_user(user_id: int):
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT user_id, role, city, direction, company_name, contact,
                   COALESCE(notify_channels, 1) AS notify_channels,
                   COALESCE(notify_logistics, 1) AS notify_logistics
            FROM users WHERE user_id = ?
            """,
            (user_id,),
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def get_user_role_counts() -> dict[str, int]:
    counts = {"all": 0, "seeker": 0, "employer": 0}
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        cur = await db.execute("SELECT COUNT(*) FROM users")
        row = await cur.fetchone()
        counts["all"] = int((row or [0])[0] or 0)
        cur = await db.execute(
            """
            SELECT role, COUNT(*) AS cnt
            FROM users
            GROUP BY role
            """
        )
        rows = await cur.fetchall()
    for role, cnt in rows:
        if role in {"seeker", "employer"}:
            counts[role] = int(cnt or 0)
    return counts


async def upsert_user_seeker(user_id: int, city: str, direction: str, contact: str) -> None:
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO users (
                user_id, role, city, direction, company_name, contact, notify_channels, notify_logistics
            )
            VALUES (?, 'seeker', ?, ?, '', ?, 1, 1)
            ON CONFLICT(user_id) DO UPDATE SET
                role = 'seeker',
                city = excluded.city,
                direction = excluded.direction,
                company_name = '',
                contact = excluded.contact,
                notify_channels = 1,
                notify_logistics = COALESCE(users.notify_logistics, 1)
            """,
            (user_id, city.strip(), direction.strip(), contact.strip()),
        )
        await db.commit()


async def upsert_user_employer(user_id: int, company_name: str) -> None:
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO users (
                user_id, role, city, direction, company_name, contact, notify_channels, notify_logistics
            )
            VALUES (?, 'employer', '', '', ?, '', 1, 1)
            ON CONFLICT(user_id) DO UPDATE SET
                role = 'employer',
                city = '',
                direction = '',
                company_name = excluded.company_name,
                contact = '',
                notify_channels = 1,
                notify_logistics = COALESCE(users.notify_logistics, 1)
            """,
            (user_id, company_name.strip()),
        )
        await db.commit()


async def set_notify_channels(user_id: int, enabled: bool) -> None:
    val = 1 if enabled else 0
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        await db.execute(
            "UPDATE users SET notify_channels = ? WHERE user_id = ?",
            (val, user_id),
        )
        await db.commit()


async def set_notify_logistics(user_id: int, enabled: bool) -> None:
    val = 1 if enabled else 0
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        await db.execute(
            "UPDATE users SET notify_logistics = ? WHERE user_id = ?",
            (val, user_id),
        )
        await db.commit()


async def insert_job(
    employer_id: int,
    title: str,
    description: str,
    city: str,
    direction: str,
    salary: str,
    contact: str,
) -> int:
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO jobs (employer_id, title, description, city, direction, salary, contact)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                employer_id,
                title.strip(),
                description.strip(),
                city.strip(),
                direction.strip(),
                salary.strip(),
                contact.strip(),
            ),
        )
        await db.commit()
        return cur.lastrowid


async def list_jobs_for_seeker(city: str, direction: str, limit: int = 15):
    """Bot ichidagi vakansiyalar. Shahar va yo‘nalish o‘xshashligi bo‘yicha saralaydi."""
    city = city.strip()
    direction = direction.strip()
    if not city and not direction:
        return []
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, title, description, city, direction, salary, contact, created_at
            FROM jobs
            WHERE is_active = 1
            ORDER BY id DESC LIMIT 200
            """
        )
        rows = [dict(r) for r in await cur.fetchall()]

    scored = []
    for row in rows:
        body = f"{row['title']} {row['direction']} {row['description']}"
        city_ok = wants_any_city(city) or text_matches_city(row["city"], city)
        dir_score = direction_match_score(body, direction)
        dir_ok = not direction or dir_score > 0
        if not city_ok or not dir_ok:
            continue
        score = (0 if wants_any_city(city) else 20) + dir_score
        if score > 0:
            scored.append((score, row["id"], row))

    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [r for _, _, r in scored[:limit]]


async def list_seekers_for_employer(employer_id: int, limit: int = 20):
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, title, description, city, direction
            FROM jobs
            WHERE employer_id = ? AND is_active = 1
            ORDER BY id DESC LIMIT 50
            """,
            (employer_id,),
        )
        jobs = [dict(r) for r in await cur.fetchall()]
        cur = await db.execute(
            """
            SELECT user_id, city, direction, contact
            FROM users
            WHERE role = 'seeker' AND LENGTH(TRIM(direction)) > 0
            ORDER BY created_at DESC LIMIT 300
            """
        )
        seekers = [dict(r) for r in await cur.fetchall()]

    matches = []
    for seeker in seekers:
        best_score = 0
        best_job = None
        for job in jobs:
            body = f"{job['title']} {job['direction']} {job['description']}"
            city_score = 20 if text_matches_city(job["city"], seeker["city"]) else 0
            dir_score = direction_match_score(body, seeker["direction"])
            score = city_score + dir_score
            if score > best_score:
                best_score = score
                best_job = job
        if best_score and best_job:
            seeker["matched_job_title"] = best_job["title"]
            seeker["match_score"] = best_score
            matches.append(seeker)

    matches.sort(key=lambda r: r["match_score"], reverse=True)
    return matches[:limit]


async def insert_channel_listing(
    channel_id: int,
    message_id: int,
    channel_username: str,
    channel_title: str,
    body: str,
    posted_at: str | None = None,
) -> int | None:
    """Qayta post bo‘lsa None."""
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        try:
            cur = await db.execute(
                """
                INSERT INTO channel_listings
                    (channel_id, message_id, channel_username, channel_title, body, posted_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    channel_id,
                    message_id,
                    (channel_username or "").strip(),
                    (channel_title or "").strip()[:200],
                    body.strip()[:12000],
                    posted_at,
                ),
            )
            await db.commit()
            return cur.lastrowid
        except aiosqlite.IntegrityError:
            return None


async def get_channel_listing(listing_id: int) -> dict | None:
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, channel_id, message_id, channel_username, channel_title, body,
                   COALESCE(posted_at, created_at) AS posted_at, created_at
            FROM channel_listings WHERE id = ?
            """,
            (listing_id,),
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def fetch_recent_channel_listings(limit: int = 120):
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, channel_id, message_id, channel_username, channel_title, body,
                   COALESCE(posted_at, created_at) AS posted_at, created_at
            FROM channel_listings
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def list_seekers_for_push(require_city: bool = True):
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        city_filter = "AND LENGTH(TRIM(city)) > 0" if require_city else ""
        cur = await db.execute(
            f"""
            SELECT user_id, city, direction
            FROM users
            WHERE role = 'seeker'
              AND COALESCE(notify_channels, 1) = 1
              AND LENGTH(TRIM(direction)) > 0
              {city_filter}
            """
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def list_seekers_for_logistics_push():
    async with aiosqlite.connect(CORE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT user_id, city, direction
            FROM users
            WHERE role = 'seeker'
              AND COALESCE(notify_logistics, 1) = 1
              AND LENGTH(TRIM(direction)) > 0
            """
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def was_push_sent(listing_id: int, user_id: int) -> bool:
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT 1 FROM channel_push_sent
            WHERE listing_id = ? AND user_id = ?
            """,
            (listing_id, user_id),
        )
        row = await cur.fetchone()
        return row is not None


async def mark_push_sent(listing_id: int, user_id: int) -> None:
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        await db.execute(
            """
            INSERT OR IGNORE INTO channel_push_sent (listing_id, user_id)
            VALUES (?, ?)
            """,
            (listing_id, user_id),
        )
        await db.commit()


async def insert_service_request(
    user_id: int,
    service_type: str,
    details: str,
    contact: str,
) -> int:
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO service_requests (user_id, service_type, details, contact)
            VALUES (?, ?, ?, ?)
            """,
            (
                user_id,
                service_type.strip()[:100],
                details.strip()[:4000],
                contact.strip()[:200],
            ),
        )
        await db.commit()
        return cur.lastrowid


def _normalize_service_status(status: str) -> str:
    st = (status or "").strip().lower()
    if st in {"new", "payment_pending", "paid", "accepted", "in_progress", "done", "rejected"}:
        return st
    return "new"


async def get_app_config(key: str, default: str = "") -> str:
    k = (key or "").strip()
    if not k:
        return default
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        cur = await db.execute(
            "SELECT value FROM app_config WHERE key = ? LIMIT 1",
            (k,),
        )
        row = await cur.fetchone()
        if not row:
            return default
        return str(row[0] or default)


async def set_app_config(key: str, value: str) -> None:
    k = (key or "").strip()
    if not k:
        return
    v = (value or "").strip()
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO app_config (key, value, updated_at)
            VALUES (?, ?, datetime('now'))
            ON CONFLICT(key) DO UPDATE SET
                value = excluded.value,
                updated_at = datetime('now')
            """,
            (k, v),
        )
        await db.commit()


async def list_service_requests(service_type_prefix: str = "", limit: int = 30):
    stype = (service_type_prefix or "").strip().lower()
    where = ""
    args: list = []
    if stype:
        where = "WHERE LOWER(service_type) LIKE ?"
        args.append(f"{stype}%")
    args.append(max(1, min(200, int(limit or 30))))
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            f"""
            SELECT id, user_id, service_type, details, contact, status, created_at
                 , payment_proof_file_id, payment_submitted_at
            FROM service_requests
            {where}
            ORDER BY id DESC
            LIMIT ?
            """,
            tuple(args),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def get_service_request(request_id: int) -> dict | None:
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, user_id, service_type, details, contact, status, created_at
                 , payment_proof_file_id, payment_submitted_at
            FROM service_requests
            WHERE id = ?
            LIMIT 1
            """,
            (int(request_id),),
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def set_service_request_status(request_id: int, status: str) -> bool:
    st = _normalize_service_status(status)
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        cur = await db.execute(
            "UPDATE service_requests SET status = ? WHERE id = ?",
            (st, int(request_id)),
        )
        await db.commit()
        return (cur.rowcount or 0) > 0


async def append_service_request_details(request_id: int, extra_text: str) -> bool:
    extra = (extra_text or "").strip()
    if not extra:
        return False
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        cur = await db.execute(
            "SELECT details FROM service_requests WHERE id = ? LIMIT 1",
            (int(request_id),),
        )
        row = await cur.fetchone()
        if not row:
            return False
        old = str(row[0] or "").strip()
        merged = (old + "\n\n" + extra).strip()[:4000]
        cur2 = await db.execute(
            "UPDATE service_requests SET details = ? WHERE id = ?",
            (merged, int(request_id)),
        )
        await db.commit()
        return (cur2.rowcount or 0) > 0


async def set_service_request_payment_proof(request_id: int, file_id: str) -> bool:
    fid = (file_id or "").strip()
    if len(fid) < 8:
        return False
    async with aiosqlite.connect(SERVICE_DB_PATH) as db:
        cur = await db.execute(
            """
            UPDATE service_requests
            SET payment_proof_file_id = ?,
                payment_submitted_at = datetime('now'),
                status = 'payment_pending'
            WHERE id = ?
            """,
            (fid[:300], int(request_id)),
        )
        await db.commit()
        return (cur.rowcount or 0) > 0


async def insert_logistics_cargo(
    user_id: int,
    from_city: str,
    to_city: str,
    cargo_type: str,
    weight: str,
    contact: str,
) -> int:
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO logistics_cargo (user_id, from_city, to_city, cargo_type, weight, contact)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                from_city.strip()[:120],
                to_city.strip()[:120],
                cargo_type.strip()[:200],
                weight.strip()[:120],
                contact.strip()[:200],
            ),
        )
        await db.commit()
        return cur.lastrowid


def _normalize_logistics_status(status: str) -> str:
    st = (status or "").strip().lower()
    if st in {"new", "band", "yopildi"}:
        return st
    return "new"


async def insert_logistics_vehicle(
    user_id: int,
    from_city: str,
    to_city: str,
    vehicle_type: str,
    capacity: str,
    contact: str,
) -> int:
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO logistics_vehicle (user_id, from_city, to_city, vehicle_type, capacity, contact)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                from_city.strip()[:120],
                to_city.strip()[:120],
                vehicle_type.strip()[:200],
                capacity.strip()[:120],
                contact.strip()[:200],
            ),
        )
        await db.commit()
        return cur.lastrowid


async def list_logistics_cargo(limit: int = 30):
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, user_id, from_city, to_city, cargo_type, weight, contact, status, created_at
            FROM logistics_cargo
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def list_logistics_vehicle(limit: int = 30):
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, user_id, from_city, to_city, vehicle_type, capacity, contact, status, created_at
            FROM logistics_vehicle
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def register_logistics_seen(key: str) -> bool:
    """Dedup uchun key saqlaydi. Yangi bo'lsa True."""
    k = (key or "").strip()
    if not k:
        return False
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            "INSERT OR IGNORE INTO logistics_seen(key) VALUES (?)",
            (k,),
        )
        await db.commit()
        return (cur.rowcount or 0) > 0


async def was_logistics_push_sent(cargo_id: int, user_id: int) -> bool:
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT 1
            FROM logistics_push_sent
            WHERE cargo_id = ? AND user_id = ?
            LIMIT 1
            """,
            (int(cargo_id), int(user_id)),
        )
        row = await cur.fetchone()
        return row is not None


async def mark_logistics_push_sent(cargo_id: int, user_id: int) -> None:
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        await db.execute(
            """
            INSERT OR IGNORE INTO logistics_push_sent (cargo_id, user_id)
            VALUES (?, ?)
            """,
            (int(cargo_id), int(user_id)),
        )
        await db.commit()


async def list_logistics_cargo_for_seeker(
    city: str,
    direction: str,
    limit: int = 20,
    max_age_hours: int | None = None,
):
    """Ish qidiruvchi uchun mos yuk e'lonlarini qaytaradi."""
    city = (city or "").strip()
    direction = (direction or "").strip()
    where = "WHERE status = 'new'"
    args: list = []
    if max_age_hours is not None:
        hours = max(1, min(24 * 30, int(max_age_hours)))
        where += " AND datetime(created_at) > datetime('now', ?)"
        args.append(f"-{hours} hours")
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            f"""
            SELECT id, from_city, to_city, cargo_type, weight, contact, status, created_at
            FROM logistics_cargo
            {where}
            ORDER BY id DESC
            LIMIT 300
            """,
            tuple(args),
        )
        rows = [dict(r) for r in await cur.fetchall()]

    scored: list[tuple[int, int, dict]] = []
    for row in rows:
        from_city = (row.get("from_city") or "").strip()
        to_city = (row.get("to_city") or "").strip()
        route = f"{from_city} {to_city}".strip()
        body = f"{row.get('cargo_type') or ''} {route}"

        unknown_route = (not route) or ("noma" in route.lower())
        city_ok = wants_any_city(city) or text_matches_city(route, city) or unknown_route
        if not city_ok:
            continue

        dir_score = direction_match_score(body, direction) if direction else 8
        if direction and dir_score <= 0:
            if body_hints_logistics_cargo(body):
                dir_score = 7
            else:
                continue

        base_city_score = 0 if wants_any_city(city) else (8 if unknown_route else 20)
        score = base_city_score + dir_score
        scored.append((score, int(row["id"]), row))

    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [r for _, _, r in scored[: max(1, min(100, int(limit or 20)))]]


async def get_logistics_cargo(cargo_id: int) -> dict | None:
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, user_id, from_city, to_city, cargo_type, weight, contact, status, created_at
            FROM logistics_cargo
            WHERE id = ?
            LIMIT 1
            """,
            (int(cargo_id),),
        )
        row = await cur.fetchone()
        return dict(row) if row else None


async def close_expired_logistics_cargo(ttl_hours: int, limit: int = 500) -> list[dict]:
    hours = max(1, min(24 * 30, int(ttl_hours)))
    lim = max(1, min(2000, int(limit or 500)))
    cutoff = f"-{hours} hours"
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, user_id, from_city, to_city
            FROM logistics_cargo
            WHERE status = 'new'
              AND datetime(created_at) <= datetime('now', ?)
            ORDER BY id ASC
            LIMIT ?
            """,
            (cutoff, lim),
        )
        rows = [dict(r) for r in await cur.fetchall()]
        if not rows:
            return []
        ids = [int(r["id"]) for r in rows]
        await db.executemany(
            "UPDATE logistics_cargo SET status = 'yopildi' WHERE id = ?",
            [(rid,) for rid in ids],
        )
        await db.executemany(
            """
            INSERT INTO logistics_status_history (cargo_id, old_status, new_status, changed_by, note)
            VALUES (?, 'new', 'yopildi', 0, 'auto_expired')
            """,
            [(rid,) for rid in ids],
        )
        await db.commit()
        return rows


async def set_logistics_cargo_status(cargo_id: int, status: str) -> bool:
    st = _normalize_logistics_status(status)
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            "UPDATE logistics_cargo SET status = ? WHERE id = ?",
            (st, int(cargo_id)),
        )
        await db.commit()
        return (cur.rowcount or 0) > 0


async def add_logistics_status_history(
    cargo_id: int,
    old_status: str,
    new_status: str,
    changed_by: int,
    note: str = "",
) -> int:
    old_st = _normalize_logistics_status(old_status)
    new_st = _normalize_logistics_status(new_status)
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            """
            INSERT INTO logistics_status_history (cargo_id, old_status, new_status, changed_by, note)
            VALUES (?, ?, ?, ?, ?)
            """,
            (int(cargo_id), old_st, new_st, int(changed_by), (note or "").strip()[:250]),
        )
        await db.commit()
        return int(cur.lastrowid or 0)


async def list_logistics_status_history(limit: int = 30):
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT h.id, h.cargo_id, h.old_status, h.new_status, h.changed_by, h.note, h.created_at,
                   c.from_city, c.to_city, c.cargo_type
            FROM logistics_status_history h
            LEFT JOIN logistics_cargo c ON c.id = h.cargo_id
            ORDER BY h.id DESC
            LIMIT ?
            """,
            (max(1, min(200, int(limit or 30))),),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def get_logistics_cargo_status_counts() -> dict[str, int]:
    result = {"new": 0, "band": 0, "yopildi": 0}
    async with aiosqlite.connect(LOGISTICS_DB_PATH) as db:
        cur = await db.execute(
            """
            SELECT status, COUNT(*) AS cnt
            FROM logistics_cargo
            GROUP BY status
            """
        )
        rows = await cur.fetchall()
    for status, cnt in rows:
        st = _normalize_logistics_status(status)
        result[st] = int(cnt or 0)
    return result


async def upsert_discovered_source(
    source_type: str,
    source_key: str,
    confidence: int = 0,
    note: str = "",
    status: str = "pending",
) -> None:
    source_type = (source_type or "").strip().lower()
    source_key = (source_key or "").strip()
    if source_type not in {"channel", "site"} or not source_key:
        return
    conf = max(0, min(100, int(confidence or 0)))
    st = (status or "pending").strip().lower()
    if st not in {"pending", "approved", "rejected"}:
        st = "pending"
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        await db.execute(
            """
            INSERT INTO discovered_sources (source_type, source_key, status, confidence, note)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(source_type, source_key) DO UPDATE SET
                confidence = MAX(discovered_sources.confidence, excluded.confidence),
                note = CASE
                    WHEN discovered_sources.note = '' THEN excluded.note
                    ELSE discovered_sources.note
                END,
                status = CASE
                    WHEN discovered_sources.status = 'pending' AND excluded.status = 'approved'
                    THEN 'approved'
                    ELSE discovered_sources.status
                END,
                approved_at = CASE
                    WHEN discovered_sources.status = 'pending' AND excluded.status = 'approved'
                    THEN datetime('now')
                    ELSE discovered_sources.approved_at
                END,
                last_seen_at = datetime('now')
            """,
            (source_type, source_key, st, conf, (note or "").strip()[:300]),
        )
        await db.commit()


async def list_discovered_sources(status: str = "pending", limit: int = 20):
    st = (status or "pending").strip().lower()
    if st not in {"pending", "approved", "rejected"}:
        st = "pending"
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            """
            SELECT id, source_type, source_key, status, confidence, note,
                   first_seen_at, last_seen_at, approved_at
            FROM discovered_sources
            WHERE status = ?
            ORDER BY confidence DESC, id DESC
            LIMIT ?
            """,
            (st, max(1, min(200, int(limit or 20)))),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def set_discovered_source_status(source_id: int, status: str) -> bool:
    st = (status or "").strip().lower()
    if st not in {"approved", "rejected", "pending"}:
        return False
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        cur = await db.execute(
            """
            UPDATE discovered_sources
            SET status = ?,
                approved_at = CASE WHEN ? = 'approved' THEN datetime('now') ELSE approved_at END,
                last_seen_at = datetime('now')
            WHERE id = ?
            """,
            (st, st, int(source_id)),
        )
        await db.commit()
        return (cur.rowcount or 0) > 0


async def list_approved_sources(source_type: str | None = None):
    stype = (source_type or "").strip().lower()
    where = "WHERE status = 'approved'"
    args: tuple = ()
    if stype in {"channel", "site"}:
        where += " AND source_type = ?"
        args = (stype,)
    async with aiosqlite.connect(CHANNEL_DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(
            f"""
            SELECT id, source_type, source_key, confidence, note
            FROM discovered_sources
            {where}
            ORDER BY confidence DESC, id DESC
            """
            ,
            args,
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]
