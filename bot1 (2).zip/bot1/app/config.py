import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
def _parse_csv_tokens(raw: str) -> tuple[str, ...]:
    raw = (raw or "").replace("\n", ",")
    return tuple(p.strip() for p in raw.split(",") if p.strip())
def _parse_channel_filter(raw: str) -> frozenset[int] | None:
    """Bo‘sh bo‘lsa — barcha kanallar (bot admin bo‘lgan). Ro‘yxat bo‘lsa — faqat shu chat_id."""
    raw = (raw or "").strip()
    if not raw:
        return None
    ids: set[int] = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        try:
            ids.add(int(part))
        except ValueError:
            continue
    return frozenset(ids) if ids else None
def _parse_int_set(raw: str) -> frozenset[int]:
    vals: set[int] = set()
    for part in (raw or "").replace("\n", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            vals.add(int(part))
        except ValueError:
            continue
    return frozenset(vals)
def _truthy(raw: str) -> bool:
    return raw.strip().lower() in ("1", "true", "yes", "on")
def _int_env(key: str, default: int = 0) -> int:
    try:
        return int((os.getenv(key, str(default)) or str(default)).strip())
    except ValueError:
        return default
@dataclass(frozen=True)
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "")
    # Masalan: -1001234567890,-1009876543210  (faqat shu kanallardan yig‘ish)
    channel_ingest_ids: frozenset[int] | None = None
    # Masalan: https://t.me/ishbor_uz,@boshqakanal  (get_chat orqali id ga aylanadi)
    tracked_source_links: tuple[str, ...] = ()
    # Logistika postlari uchun alohida chat_id filtri (bo'sh bo'lsa barcha ruxsat etilgan chatlar)
    logistics_ingest_ids: frozenset[int] | None = None
    # Logistika manbalari: @kanal, t.me/link yoki chat_id
    logistics_source_links: tuple[str, ...] = ()
    # Logistika sayt manbalari (HTML sahifadan keyword bo'yicha yig'ish)
    logistics_site_urls: tuple[str, ...] = ()
    logistics_site_poll_seconds: int = 900
    logistics_cargo_ttl_hours: int = 48
    logistics_expiry_check_seconds: int = 300
    source_discovery_poll_seconds: int = 3600
    viloyat_kunlik_onlayn_seeds_enabled: bool = True
    source_discovery_seed_urls: tuple[str, ...] = ()
    source_discovery_auto_approve: bool = True
    source_discovery_approve_min_score: int = 75
    ai_discovery_enabled: bool = False
    sources_resolve_refresh_seconds: int = 300
    telethon_tracked_refresh_seconds: int = 180
    max_push_per_post: int = 400
    telethon_enabled: bool = False
    telethon_api_id: int = 0
    telethon_api_hash: str = ""
    telethon_session_path: str = ""
    telethon_channels: tuple[str, ...] = ()
    telethon_backfill_limit: int = 0
    telethon_backfill_days: int = 5
    ai_match_enabled: bool = False
    ai_chat_enabled: bool = False
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.0-flash"
    ai_match_min_score: int = 60
    admin_ids: frozenset[int] = frozenset()
    auto_test_mini_app_url: str = ""
    ad_payment_card: str = ""
    ad_payment_owner: str = ""
    ad_admin_contact: str = ""
    # Sayt / ilova / bot buyurtmasi — foydalanuvchiga ko‘rinadigan ijrochi aloqasi
    dev_order_contact: str = ""

    @staticmethod
    def load() -> "Settings":
        ingest = _parse_channel_filter(os.getenv("CHANNEL_INGEST_IDS", ""))
        links = _parse_csv_tokens(os.getenv("TRACKED_SOURCE_LINKS", ""))
        lim = os.getenv("MAX_PUSH_PER_POST", "400").strip()
        try:
            max_push = max(1, min(5000, int(lim)))
        except ValueError:
            max_push = 400
        default_session = (
            Path(__file__).resolve().parent.parent / "data" / "telethon_user"
        )
        return Settings(
            bot_token=os.getenv("BOT_TOKEN", ""),
            channel_ingest_ids=ingest,
            tracked_source_links=links,
            logistics_ingest_ids=_parse_channel_filter(os.getenv("LOGISTICS_INGEST_IDS", "")),
            logistics_source_links=_parse_csv_tokens(os.getenv("LOGISTICS_SOURCE_LINKS", "")),
            logistics_site_urls=_parse_csv_tokens(os.getenv("LOGISTICS_SITE_URLS", "")),
            logistics_site_poll_seconds=max(120, min(86400, _int_env("LOGISTICS_SITE_POLL_SECONDS", 900))),
            logistics_cargo_ttl_hours=max(1, min(24 * 30, _int_env("LOGISTICS_CARGO_TTL_HOURS", 48))),
            logistics_expiry_check_seconds=max(30, min(86400, _int_env("LOGISTICS_EXPIRY_CHECK_SECONDS", 300))),
            source_discovery_poll_seconds=max(300, min(86400, _int_env("SOURCE_DISCOVERY_POLL_SECONDS", 3600))),
            viloyat_kunlik_onlayn_seeds_enabled=_truthy(
                os.getenv("VILOYAT_KUNLIK_ONLAYN_SEEDS_ENABLED", "true")
            ),
            source_discovery_seed_urls=_parse_csv_tokens(os.getenv("SOURCE_DISCOVERY_SEED_URLS", "")),
            source_discovery_auto_approve=_truthy(os.getenv("SOURCE_DISCOVERY_AUTO_APPROVE", "true")),
            source_discovery_approve_min_score=max(40, min(99, _int_env("SOURCE_DISCOVERY_APPROVE_MIN_SCORE", 75))),
            ai_discovery_enabled=_truthy(os.getenv("AI_DISCOVERY_ENABLED", "")),
            sources_resolve_refresh_seconds=max(60, min(86400, _int_env("SOURCES_RESOLVE_REFRESH_SECONDS", 300))),
            telethon_tracked_refresh_seconds=max(60, min(3600, _int_env("TELETHON_TRACKED_REFRESH_SECONDS", 180))),
            max_push_per_post=max_push,
            telethon_enabled=_truthy(os.getenv("TELETHON_ENABLED", "")),
            telethon_api_id=_int_env("TELEGRAM_API_ID", 0),
            telethon_api_hash=(os.getenv("TELEGRAM_API_HASH", "") or "").strip(),
            telethon_session_path=(
                os.getenv("TELETHON_SESSION_PATH", "").strip() or str(default_session)
            ),
            telethon_channels=_parse_csv_tokens(os.getenv("TELETHON_CHANNELS", "")),
            telethon_backfill_limit=max(0, min(200, _int_env("TELETHON_BACKFILL_LIMIT", 0))),
            telethon_backfill_days=max(1, min(3650, _int_env("TELETHON_BACKFILL_DAYS", 5))),
            ai_match_enabled=_truthy(os.getenv("AI_MATCH_ENABLED", "")),
            ai_chat_enabled=_truthy(os.getenv("AI_CHAT_ENABLED", "")),
            gemini_api_key=(os.getenv("GEMINI_API_KEY", "") or "").strip(),
            gemini_model=(os.getenv("GEMINI_MODEL", "gemini-2.0-flash") or "gemini-2.0-flash").strip(),
            ai_match_min_score=max(0, min(100, _int_env("AI_MATCH_MIN_SCORE", 60))),
            admin_ids=_parse_int_set(os.getenv("ADMIN_IDS", "")),
            auto_test_mini_app_url=(os.getenv("AUTO_TEST_MINI_APP_URL", "") or "").strip(),
            ad_payment_card=(os.getenv("AD_PAYMENT_CARD", "") or "").strip(),
            ad_payment_owner=(os.getenv("AD_PAYMENT_OWNER", "") or "").strip(),
            ad_admin_contact=(os.getenv("AD_ADMIN_CONTACT", "") or "").strip(),
            dev_order_contact=(os.getenv("DEV_ORDER_CONTACT", "") or "").strip(),
        )


def get_settings() -> Settings:
    s = Settings.load()
    if not s.bot_token:
        raise RuntimeError("BOT_TOKEN .env faylida yo‘q")
    return s
