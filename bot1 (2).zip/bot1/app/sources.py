"""TRACKED_SOURCE_LINKS (.env) dagi t.me havolalarini chat_id ga aylantirish."""

from __future__ import annotations

import logging
import re

from aiogram import Bot

from app import db
from app.config import Settings

log = logging.getLogger(__name__)

# Ishga tushgandan keyin: None = barcha ruxsat etilgan chatlar; frozenset = faqat shular
_runtime_ingest_ids: frozenset[int] | None = None
_runtime_logistics_ids: frozenset[int] | None = None


def set_runtime_ingest_ids(ids: frozenset[int] | None) -> None:
    global _runtime_ingest_ids
    _runtime_ingest_ids = ids


def set_runtime_logistics_ids(ids: frozenset[int] | None) -> None:
    global _runtime_logistics_ids
    _runtime_logistics_ids = ids


def ingest_allowed(chat_id: int) -> bool:
    if _runtime_ingest_ids is None:
        return True
    return chat_id in _runtime_ingest_ids


def logistics_ingest_allowed(chat_id: int) -> bool:
    if _runtime_logistics_ids is None:
        return True
    return chat_id in _runtime_logistics_ids


def _split_env_list(raw: str) -> tuple[str, ...]:
    raw = (raw or "").replace("\n", ",")
    return tuple(p.strip() for p in raw.split(",") if p.strip())


def _parse_chat_id_token(s: str) -> int | None:
    s = s.strip()
    if re.fullmatch(r"-?\d+", s):
        try:
            return int(s)
        except ValueError:
            return None
    return None


def _username_from_link_token(token: str) -> str | None:
    """
    @name, name, https://t.me/name, https://t.me/name/123 -> name
    https://t.me/+xxx yoki joinchat -> None (bot API orqali avtomatik kira olmaydi)
    """
    t = token.strip()
    if not t:
        return None
    if t.startswith("@"):
        u = t[1:].split("/")[0].split("?")[0]
        return u or None
    low = t.lower()
    if "t.me/" in low:
        idx = low.index("t.me/") + len("t.me/")
        rest = t[idx:].lstrip("/")
        if not rest:
            return None
        slug = rest.split("/")[0].split("?")[0]
        if slug.startswith("+") or slug.lower() == "joinchat":
            return None
        return slug.lstrip("@") or None
    if re.fullmatch(r"[A-Za-z0-9_]{4,64}", t):
        return t
    return None


async def resolve_and_apply(bot: Bot, settings: Settings) -> None:
    """Asosiy va logistika manbalarini resolve qilib runtime filtrlarga yozadi."""
    approved = await db.list_approved_sources()
    approved_channels: list[str] = [
        r.get("source_key", "")
        for r in approved
        if r.get("source_type") == "channel" and r.get("source_key")
    ]
    approved_sites: list[str] = [
        r.get("source_key", "")
        for r in approved
        if r.get("source_type") == "site" and r.get("source_key")
    ]

    async def _resolve_source_ids(
        direct_ids: frozenset[int] | None,
        links: tuple[str, ...],
        scope: str,
    ) -> set[int]:
        ids: set[int] = set()
        if direct_ids:
            ids.update(direct_ids)
        for token in links:
            cid = _parse_chat_id_token(token)
            if cid is not None:
                ids.add(cid)
                continue
            un = _username_from_link_token(token)
            if not un:
                log.warning(
                    "%s: manba tushunarsiz yoki maxfiy havola (t.me/+...): %r",
                    scope,
                    token,
                )
                continue
            try:
                chat = await bot.get_chat(f"@{un}")
                ids.add(chat.id)
                log.info("%s: manba hal qilindi @%s -> chat_id=%s", scope, un, chat.id)
            except Exception as e:
                log.warning("%s: get_chat(@%s) ishlamadi (%s)", scope, un, e)
        return ids

    ids = await _resolve_source_ids(
        settings.channel_ingest_ids,
        tuple(settings.tracked_source_links) + tuple(approved_channels),
        "Asosiy manba",
    )
    logistics_ids = await _resolve_source_ids(
        settings.logistics_ingest_ids,
        tuple(settings.logistics_source_links) + tuple(approved_channels),
        "Logistika manba",
    )

    if not ids:
        set_runtime_ingest_ids(None)
        log.info("Asosiy manbalar bo'sh — barcha ruxsat etilgan chatlardan yig'iladi.")
    else:
        set_runtime_ingest_ids(frozenset(ids))
        log.info("Asosiy yig'ish filtri: %s ta chat_id", len(ids))

    if not logistics_ids:
        set_runtime_logistics_ids(None)
        log.info("Logistika manbalar bo'sh — barcha ruxsat etilgan chatlardan yig'iladi.")
    else:
        set_runtime_logistics_ids(frozenset(logistics_ids))
        log.info("Logistika yig'ish filtri: %s ta chat_id", len(logistics_ids))

    if approved_sites:
        log.info("Tasdiqlangan sayt manbalar topildi: %s ta", len(approved_sites))
