from __future__ import annotations

import asyncio
import logging

from aiogram import Bot

from app import db

log = logging.getLogger(__name__)


async def run_logistics_expiry_loop(
    bot: Bot,
    ttl_hours: int,
    poll_seconds: int = 300,
) -> None:
    ttl = max(1, min(24 * 30, int(ttl_hours)))
    delay = max(30, min(86400, int(poll_seconds)))
    log.info("Logistika expiry worker yoqildi: ttl=%s soat, poll=%s s", ttl, delay)
    while True:
        try:
            expired_rows = await db.close_expired_logistics_cargo(ttl, limit=500)
            if expired_rows:
                log.info("Muddati o'tgan yuklar yopildi: %s ta", len(expired_rows))
                for row in expired_rows[:400]:
                    uid = int(row.get("user_id") or 0)
                    if uid <= 0:
                        continue
                    try:
                        await bot.send_message(
                            uid,
                            (
                                f"⏳ CARGO-{row.get('id')} e'lon muddati tugadi va avtomatik yopildi.\n"
                                "Kerak bo'lsa yangi yuk e'loni joylang."
                            ),
                        )
                    except Exception:
                        continue
                    await asyncio.sleep(0.02)
        except Exception as e:
            log.warning("Logistika expiry worker xato: %s", e)
        await asyncio.sleep(delay)

