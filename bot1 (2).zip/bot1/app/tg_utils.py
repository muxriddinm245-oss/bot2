def channel_message_url(chat_id: int, message_id: int, username: str | None) -> str:
    u = (username or "").strip().lstrip("@")
    if u:
        return f"https://t.me/{u}/{message_id}"
    sid = str(chat_id)
    if sid.startswith("-100"):
        return f"https://t.me/c/{sid[4:]}/{message_id}"
    return f"https://t.me/c/{sid.lstrip('-')}/{message_id}"
