import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from app.config import get_settings
from app import db
from app.handlers import setup_routers
from app.sources import resolve_and_apply
from app.sources_resolve_worker import run_sources_resolve_loop
from app.viloyat_kunlik_onlayn_seeds import VILOYAT_KUNLIK_ONLAYN_SEED_URLS


def _merge_seed_urls(*groups: tuple[str, ...]) -> tuple[str, ...]:
    seen: set[str] = set()
    out: list[str] = []
    for g in groups:
        for u in g:
            u = (u or "").strip()
            if u and u not in seen:
                seen.add(u)
                out.append(u)
    return tuple(out)


async def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    logging.basicConfig(level=logging.INFO, stream=sys.stdout)
    settings = get_settings()
    await db.init_db()
    approved_sites = [r.get("source_key", "") for r in await db.list_approved_sources("site")]
    merged_site_urls = tuple(
        u for u in (tuple(settings.logistics_site_urls) + tuple(approved_sites)) if u
    )
    viloyat_seeds = (
        VILOYAT_KUNLIK_ONLAYN_SEED_URLS if settings.viloyat_kunlik_onlayn_seeds_enabled else ()
    )
    merged_discovery_seed_urls = _merge_seed_urls(
        tuple(settings.source_discovery_seed_urls),
        merged_site_urls,
        viloyat_seeds,
    )
    log = logging.getLogger(__name__)
    if viloyat_seeds:
        log.info(
            "Viloyat + Qoraqalpog' kunlik/onlayn seed URL: %s ta (jami discovery seed: %s)",
            len(viloyat_seeds),
            len(merged_discovery_seed_urls),
        )

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(setup_routers())

    async def _on_startup() -> None:
        await resolve_and_apply(bot, get_settings())

    dp.startup.register(_on_startup)

    site_worker = None
    if merged_site_urls:
        from app.logistics_site_worker import run_site_ingest_loop

        site_worker = run_site_ingest_loop(
            bot,
            merged_site_urls,
            settings.logistics_site_poll_seconds,
        )

    discovery_worker = None
    if merged_discovery_seed_urls:
        from app.source_discovery_worker import run_source_discovery_loop

        discovery_worker = run_source_discovery_loop(
            merged_discovery_seed_urls,
            settings.source_discovery_poll_seconds,
            auto_approve=settings.source_discovery_auto_approve,
        )

    from app.logistics_expiry_worker import run_logistics_expiry_loop

    expiry_worker = run_logistics_expiry_loop(
        bot,
        settings.logistics_cargo_ttl_hours,
        settings.logistics_expiry_check_seconds,
    )

    tasks = [
        dp.start_polling(bot),
        expiry_worker,
        run_sources_resolve_loop(bot, settings.sources_resolve_refresh_seconds),
    ]
    if settings.telethon_enabled:
        from app.telethon_worker import run_until_disconnected

        tasks.append(run_until_disconnected(bot, settings))
    if site_worker is not None:
        tasks.append(site_worker)
    if discovery_worker is not None:
        tasks.append(discovery_worker)
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
