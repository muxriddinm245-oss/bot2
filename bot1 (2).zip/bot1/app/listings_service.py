"""Kanal/guruh postlarini bazaga yozish va ish qidiruvchilarga push (Bot API)."""

from __future__ import annotations

import asyncio
import html
import logging
from datetime import datetime, timezone

from aiogram import Bot

from app import db
from app.ai_matcher import match_listing_to_direction
from app.config import get_settings
from app.logistics_ingest_service import save_logistics_from_text
from app.logistics_push_service import push_cargo_to_seekers
from app.matching import direction_match_score, text_matches_city, wants_any_city
from app.sources import ingest_allowed, logistics_ingest_allowed
from app.timefmt import human_age

log = logging.getLogger(__name__)


async def save_listing_and_push(
    bot: Bot,
    *,
    channel_id: int,
    message_id: int,
    channel_username: str,
    channel_title: str,
    body: str,
    posted_at: datetime | None = None,
    push_enabled: bool = True,
    check_ingest_filter: bool = True,
    require_city: bool = True,
) -> bool:
    """Matnli postni saqlaydi; muvaffaqiyatli bo‘lsa push navbatga qo‘yiladi."""
    text = (body or "").strip()
    if not text:
        return False
    if check_ingest_filter and not ingest_allowed(channel_id):
        return False

    lid = await db.insert_channel_listing(
        channel_id=channel_id,
        message_id=message_id,
        channel_username=channel_username.strip(),
        channel_title=channel_title.strip()[:200],
        body=text,
        posted_at=_iso_utc(posted_at),
    )
    if lid is None:
        return False

    log.info("Listing saqlandi #%s (chat=%s)", lid, channel_id)
    # Logistika manbalaridan kelgan postlarni avtomatik alohida bazaga ajratib saqlaymiz.
    if logistics_ingest_allowed(channel_id):
        try:
            _, cargo_ids = await save_logistics_from_text(user_id=int(channel_id), text=text)
            for cargo_id in cargo_ids[:50]:
                asyncio.create_task(push_cargo_to_seekers(bot, cargo_id))
        except Exception as e:
            log.debug("Logistika auto-ingest xato: chat=%s err=%s", channel_id, e)

    if push_enabled:
        asyncio.create_task(push_listing_to_seekers(bot, lid, require_city=require_city))
    return True


async def push_listing_to_seekers(bot: Bot, listing_id: int, require_city: bool = True) -> None:
    settings = get_settings()
    ai_enabled = settings.ai_match_enabled and bool(settings.gemini_api_key.strip())
    row = await db.get_channel_listing(listing_id)
    if not row:
        return
    body = row["body"]
    age = human_age(row.get("posted_at") or row.get("created_at"))
    age_line = f"⏱ {html.escape(age)}\n" if age else ""
    seekers = await db.list_seekers_for_push(require_city=require_city)
    sent = 0
    snippet = html.escape(body[:900] + ("…" if len(body) > 900 else ""))
    ai_direction_cache: dict[str, tuple[bool, int] | None] = {}

    for s in seekers:
        if sent >= settings.max_push_per_post:
            break
        uid = int(s["user_id"])
        city = s.get("city") or ""
        direction = (s.get("direction") or "").strip()
        if require_city and not wants_any_city(city) and not text_matches_city(body, city):
            continue
        rule_score = direction_match_score(body, direction)
        if ai_enabled:
            cache_key = direction.lower()
            ai_decision = ai_direction_cache.get(cache_key)
            if ai_decision is None and cache_key not in ai_direction_cache:
                result = await match_listing_to_direction(
                    api_key=settings.gemini_api_key,
                    model=settings.gemini_model,
                    listing_text=body,
                    seeker_direction=direction,
                )
                if result is None:
                    ai_direction_cache[cache_key] = None
                else:
                    ai_direction_cache[cache_key] = (result.match, result.score)
                ai_decision = ai_direction_cache.get(cache_key)
            if ai_decision is None:
                if rule_score <= 0:
                    continue
            else:
                is_match, ai_score = ai_decision
                if (not is_match) or ai_score < settings.ai_match_min_score:
                    continue
        elif rule_score <= 0:
            continue
        if await db.was_push_sent(listing_id, uid):
            continue
        msg = (
            f"📢 <b>Yangi mos e’lon</b>\n"
            f"{age_line}"
            f"{snippet}\n\n"
            f"<i>Profilingizga yaqin deb topdim. «📣 Avtomatik xabarlar» bilan boshqaring.</i>"
        )
        try:
            await bot.send_message(uid, msg, parse_mode="HTML", disable_web_page_preview=True)
            await db.mark_push_sent(listing_id, uid)
            sent += 1
        except Exception as e:
            log.debug("Push rad: user=%s err=%s", uid, e)
        await asyncio.sleep(0.04)


def _iso_utc(dt: datetime | None) -> str | None:
    if not dt:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")
