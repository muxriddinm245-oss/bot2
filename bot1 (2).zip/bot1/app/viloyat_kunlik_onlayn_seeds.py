"""
12 ta viloyat + Qoraqalpog'iston Respublikasi bo'yicha kunlik va onlayn ish e'lonlari uchun manba seedlari.

Har bir qator — asosan `t.me/s/@kanal` (ochiq postlar HTML), `source_discovery_worker`
sahifadan boshqa kanallarni ham topishi mumkin.
"""

from __future__ import annotations

# 12 viloyat + Qoraqalpog'iston; keyin respublika bo'yicha kunlik/onlayn va TGStat katalog
VILOYAT_KUNLIK_ONLAYN_SEED_URLS: tuple[str, ...] = (
    "https://t.me/s/uwork_andijon",
    "https://t.me/s/Buxoroda_ish",
    "https://t.me/s/ISHBORFARGONADA",
    "https://t.me/s/JizzaxBozor",
    "https://t.me/s/IshborQashqadaryo",
    "https://t.me/s/navoijobs",
    "https://t.me/s/Namanganishbor",
    "https://t.me/s/samarqand_urgut_ish",
    "https://t.me/s/guliston",
    "https://t.me/s/surxondaryodaishlar",
    "https://t.me/s/Raboota_Chirchika",
    "https://t.me/s/Xorazm_ish",
    "https://t.me/s/uWork_Qoraqalp",
    "https://t.me/s/nukus_vakans",
    "https://t.me/s/est_rabota_KR",
    "https://t.me/s/samarqand_ishlar_kerak",
    "https://t.me/s/uzishborzur",
    "https://t.me/s/podrabotka_vakansiiiz",
    "https://t.me/s/Ish_Toshkent",
    "https://t.me/s/headhunter_uz",
    "https://uz.tgstat.com/en/career",
)
