# Avto test mini-ilova

`index.html` ni oddiy static hostingga joylang (Netlify, Vercel static, GitHub Pages).

Keyin `.env` ichiga URL yozing:

`AUTO_TEST_MINI_APP_URL=https://your-domain.com/auto-test/index.html`

Shundan keyin botdagi `🚗 Avto test mini-ilova` tugmasi mini-ilovani ochadi.
